﻿using System;
using MobilePay.Shared.IntegrationEvent.Attributes;
using MobilePay.Shared.Merchant.AcceptanceTests.Utilities;
using Xunit;

namespace MobilePay.Shared.Merchant.AcceptanceTests.UnitTests.Utilities;

public class HelperMethods_Should
{
    [Fact]
    public void ReturnIntegrationEventAttributeValue()
    {
        var result = HelperMethods.GetIntegrationEventName<MyClassWithIntegrationEventAttribute>(Guid.NewGuid());
        
        Assert.Equal("TestEvent", result);
    }

    [Fact]
    public void ReturnEventNameFieldValue()
    {
        var result = HelperMethods.GetIntegrationEventName<MyClassWithEventNameField>(Guid.NewGuid());
        
        Assert.Equal(MyClassWithEventNameField.EventName, result);
    }
    
    [Fact]
    public void ReturnTypeStringFieldValue()
    {
        var result = HelperMethods.GetIntegrationEventName<MyClassWithTypeStringField>(Guid.NewGuid());
        
        Assert.Equal(MyClassWithTypeStringField.TypeString, result);
    }

    [Fact]
    public void Throw_When_NeitherEventNameNorTypeStringFieldExists()
    {
        var correlationId = Guid.NewGuid();
        var exception = Assert.Throws<InvalidOperationException>(() => HelperMethods.GetIntegrationEventName<MyClassWithoutEventNameFieldAndWithoutTypeStringField>(correlationId));

        Assert.Contains(correlationId.ToString(), exception.Message);
    }
    
    [IntegrationEvent("TestBC", "TestEvent")]
    private class MyClassWithIntegrationEventAttribute {}

    private class MyClassWithEventNameField
    {
        public const string EventName = nameof(EventName);
    }
    
    private class MyClassWithTypeStringField
    {
        public const string TypeString = nameof(TypeString);
    }
    
    private class MyClassWithoutEventNameFieldAndWithoutTypeStringField
    {
        public const string RandomField = nameof(RandomField);
    }
}