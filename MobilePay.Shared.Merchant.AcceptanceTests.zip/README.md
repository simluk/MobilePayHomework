# Introduction
This repository was born as a attempt to package up recurring code used in Bits Please acceptance tests projects.
While at it, we also decided to add some helper methods that conveniently wrap the retry and delay logics, thus making tests less prone to accidental racing conditions.
Finally, the package provides mocks to some of the shared infrastructure components, namely - notification service and deferred messages.
Here we will quickly go over the basics of what you need to know to use the package

# CorrelationId
One of the biggest problems we hit initially, was correlating the logs for the specific test. Therefore, we decided to introduce a practice of keeping CorrelationId per-test, ensuring its used for all operations in that scope. This allows us to easily correlate all logs in internal Kibana (GoCD logs are too unstructured to be useful at large amount of tests anyway)

# Getting Started
There are several things that should be done in order to use the package:
1.  **Define test collection** - the package as of today is not able to run tests in parallel. The way xUnit controls parallel execution is through collections - multiple collections are executed in parallel, and tests inside single collection are executed sequentially. Therefore we need a single collection that could be applied to all test classes:
    ``` csharp
    [CollectionDefinition(nameof(AcceptanceTestCollection))]
    public class AcceptanceTestCollection : ICollectionFixture<AcceptanceTestFixtureData>
    {
    }
    ```
2.  **Configure IoC** - AcceptanceTestFixtureDataBase is a shared abstract class that configures most of the dependencies. However some of the dependencies are not known to the testing framework itself, so this exposes abstract methods to configure them:
    1. RegisterConsumer - this code is used to configure IHost for your consumer service. Example:
        ``` csharp
            protected override IServiceCollection RegisterConsumer(IServiceCollection serviceCollection, IConfigurationRoot configuration)
                {
                    return serviceCollection.AddSingleton(
                        _ =>
                        {
                            return Host
                                .CreateDefaultBuilder()
                                .UseContentRoot(Directory.GetCurrentDirectory() + "/../../../../Consumer.Service")
                                .AddHostedService<ConsumerService>()
                                .ConfigureServices((context, consumerServices) => consumerServices.AddConsumerServices(context.Configuration))
                                .Build();
                        });
                }
        ```
    2. RegisterWebApplication - this is used to register WebApplicationFactory for your startup class. Example:
        ``` csharp
            protected override IServiceCollection RegisterWebApplication(IServiceCollection serviceCollection, IConfigurationRoot configuration)
            {
                return serviceCollection.AddSingleton<WebApplicationFactory<Startup>>();
            } 
        ```
    3. RegisterCustomDependencies - this is meant to add any non packaged dependencies that your tests need to run, such as custom HTTP clients or IntegrationEventPublishers. Also, it must add a RestApiHttpClientFactory for your Startup class. Example:
        ``` csharp
            protected override IServiceCollection RegisterCustomDependencies(IServiceCollection serviceCollection, IConfigurationRoot configuration)
            {
                serviceCollection.AddSingleton<IRestApiHttpClientFactory, RestApiHttpClientFactory<Startup>>();
                serviceCollection.AddTransient<MerchantHttpClient>();
                serviceCollection.AddTransient<KnowYourCustomerIntegrationEventPublisher>();
                serviceCollection.AddSingleton(new Fixture().AddAutoMoqDataCustomizations());

                return serviceCollection;
            }
        ```
3.  **Extend AcceptanceTestBase** - It's not mandatory, but there are quite a few things that we typically have to do for all AcceptanceTest classes:
    1. Applying a collection attribute - this is meant to ensure sequential execution of all tests
    2. Exposing TestWideCorrelationId - since every test creates its own instance of test class, AcceptanceTestBase class exposes unique Guid for each particular test
    3. Exposing TestDataBuilder - this is where we typically place a method allowing us to get an instance of TestDataBuilder
    4. Disposing consumers - whenever you await for event, a new consumer is created and subscribed to an exchange. If you do that for many tests, you might endup with exchange that is bound to 100 queues, making tests slow. You can dispose them on your own, but if your test class extends AcceptanceTestBase, it takes care of the disposing on it's own
    You can see an example here: https://azuredevops.danskenet.net/Main/MobilePay/_git/MobilePay.Merchant.CustomerDueDiligence?path=%2FAcceptanceTests%2FTests%2FCustomerDueDiligenceTestBase.cs
3.  **Define your test data** - This is the part where the package does very little and leaves most of it for you. Every test should have some sort of state - if you're testing merchant features, its likely you will need to store the ID of merchant, merchant user, etc. This class is meant to encompass data relevant to your test collection.
4.  **Implement TestDataBuilder** - Now that you have a class to store your test state, you need to have helper class that exposes methods to bring test data to desired state. F.e. - in order to test merchant onboarding, you would need a valid merchant, who has filled in the KYC data. This is where TestDataBuilder comes in. Typically in our solutions, TestDataBuilder extends TestDataBuilderBase, and exposes bunch of methods using Builder pattern. This is our way of doing the 'arrange' part. You can see an example here: https://azuredevops.danskenet.net/Main/MobilePay/_git/MobilePay.Merchant.CustomerDueDiligence?path=%2FAcceptanceTests%2FTestData%2FTestDataBuilder.cs


# Configuration
The package expects *AcceptanceTestsConfiguration* and optionally *HttpServerMockConfiguration* to be present in the appsettings.json, containing the following items:

1. UseTestServer - This specifies if API should run in memory (locally, AzureDevOps pipelines) or the tests should expect an actual instance running somewhere (GoCD)
2. RestApiHost - specifies an URL for API root, in case running in GoCD
3. HttpServerMockConfiguration - specifies an array of URLs for mock API. It is dedicated for mocking http endpoints. Ex. third party apis that your code has an integration with. Make sure that BaseUrls array contains third party URL in your application configuration so that it would be invoked by acceptance tests. By adding this configuration section you are registering a singleton instance of HttpServerMock which will be instantiated in TestDataBuilderBase class for use in your test data builders. Trying to access this object without having the config in appsettings will result in a runtime NullReferenceException.
4. EventualConsistencyTimeout - Time interval during which we expect eventual consistency issues to self-resolve. F.e. - events to arrive, APIs to start returning correct values, emails to be sent, etc. We currently use a value of "00:00:02". Tried setting it lower, but noticed that every now and then tests will fail because of cassandra package taking longer to respond to queries. I guess just play around and see what works for your service :)
5. EventualConsistencyTimeBetweenRetries - Time interval we delay for between attempts, in cases where polling must be used - f.e. when we poll API to get the result we want eventually. We currently use "00:00:00.05" which equals to 50ms

Example:

        "AcceptanceTestsConfiguration": {
            "UseTestServer": true,
            "RestApiHost": "http://localhost:5000/",
            "EventualConsistencyTimeout": "00:00:02",
            "EventualConsistencyTimeBetweenRetries": "00:00:00.05"
        },
        "HttpServerMockConfiguration": {
            "BaseUrls": ["http://localhost:2627/"]
        }

# Why bother though?
1. If you are extending AcceptanceTestBase and TestDataBuilderBase classes, you get a bunch of helper methods for your acceptance tests and test data setup respectively. The methods have built-in retry policies that keep retrying assertions until success, or EventualConsistencyTimeout is reached. Methods also accept correlationId where applicable, to make sure that the tests don't interfere with each other:
Documentation for the methods is provided via XML comments
2. FluentHttpClient - we use this as a basis for all of our testing HTTP client. Uses builder pattern to create HTTP requests, allows easily adding the correct authorization
3. IntegrationEventPublisher - provides generic functionality to publish integration events. We extend this in integration event publishers for specific BCs

#Sample test project
We haven't had time to implement a sample, but you could take a look at other services that already use the package, for example this one:
https://azuredevops.danskenet.net/Main/MobilePay/_git/MobilePay.Merchant.CustomerDueDiligence?path=%2FAcceptanceTests

