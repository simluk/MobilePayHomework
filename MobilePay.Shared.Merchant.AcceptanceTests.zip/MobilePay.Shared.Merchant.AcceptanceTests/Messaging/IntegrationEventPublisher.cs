using System;
using System.Threading.Tasks;
using Db.Messaging.Bus.Message;
using Db.Messaging.Bus.MessageBus;
using MobilePay.Shared.Merchant.AcceptanceTests.Extensions;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Messaging
{
    /// <summary>
    /// Generic integration event publisher
    /// </summary>
    public class IntegrationEventPublisher
    {
        private readonly IMessageBus _messageBus;
        private int _sequence = 0;
        
        protected IntegrationEventPublisher(IMessageBus messageBus)
        {
            _messageBus = messageBus;
        }

        /// <summary>
        /// Publish an integration event as if it was coming from specific BC
        /// </summary>
        /// <param name="correlationId">CorrelationId to use when publishing a message</param>
        /// <param name="integrationEvent">Integration event to publish</param>
        /// <param name="boundedContext">BoundedContext the event should be published from</param>
        /// <param name="eventName">Name of the integration event</param>
        /// <param name="sequence">Sequence of the integration event</param>
        /// <typeparam name="T">Type of the integration event</typeparam>
        /// <returns>Task</returns>
        protected async Task Publish<T>(Guid correlationId, T integrationEvent, string boundedContext, string eventName, int sequence = int.MinValue) where T : class
        {
            await _messageBus.PublishEvent(
                boundedContext,
                eventName,
                integrationEvent,
                sequence == int.MinValue ? _sequence++ : sequence,
                correlationId);
        }
        
        /// <summary>
        /// Publish an integration event with custom message properties as if it was coming from specific BC
        /// </summary>
        /// <param name="correlationId">CorrelationId to use when publishing a message</param>
        /// <param name="integrationEvent">Integration event to publish</param>
        /// <param name="boundedContext">BoundedContext the event should be published from</param>
        /// <param name="eventName">Name of the integration event</param>
        /// <param name="messageProperties">Published event meta data</param>
        /// <param name="sequence">Sequence of the integration event</param>
        /// <typeparam name="T">Type of the integration event</typeparam>
        /// <returns>Task</returns>
        protected async Task Publish<T>(Guid correlationId, T integrationEvent, string boundedContext, string eventName, MessageProperties messageProperties, int sequence = int.MinValue) where T : class
        {
            await _messageBus.PublishEvent(
                boundedContext,
                eventName,
                integrationEvent,
                sequence == int.MinValue ? _sequence++ : sequence,
                correlationId,
                messageProperties);
        }
    }
}