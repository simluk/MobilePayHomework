using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading.Tasks;
using Db.Messaging.Bus.Message;
using Db.Messaging.Bus.MessageBus;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Messaging
{
    public class EventAwaiter
    {
        private readonly IDictionary<Guid, ICollection<IDisposable>> _consumersByCorrelationId;

        private readonly IMessageBus _messageBus;
        
        public EventAwaiter(IMessageBus messageBus)
        {
            _consumersByCorrelationId = new ConcurrentDictionary<Guid, ICollection<IDisposable>>();
            _messageBus = messageBus;
        }
        
        public TaskCompletionSource<MessageEntity<TEvent>> WaitForEvent<TEvent>(
            Guid correlationId,
            string boundedContext = null,
            string eventName = null,
            Func<MessageEntity<TEvent>, bool> assertion = null)
            where TEvent : class
        {
            var eventEmitted = new TaskCompletionSource<MessageEntity<TEvent>>();
            var handler = CreateFuncHandler(correlationId, eventEmitted, assertion);
            
            var consumer = _messageBus.Subscribe<TEvent>(
                boundedContext,
                eventName,
                async x =>
                {
                    if (x.Message.GetType() == typeof(TEvent))
                    {
                        await handler(x);
                    }
                },
                config =>
                {
                    config.Durable = false;
                    config.Name = Guid.NewGuid().ToString();
                    config.AutoDelete = true;
                });

            RegisterConsumer(correlationId, consumer);

            return eventEmitted;
        }

        private static Func<MessageEntity<TEvent>, Task> CreateFuncHandler<TEvent>(Guid correlationId, TaskCompletionSource<MessageEntity<TEvent>> eventEmitted, Func<MessageEntity<TEvent>, bool> eventAssertion) =>
            messageEntity =>
            {
                if (messageEntity.Properties.CorrelationId == correlationId.ToString() &&
                    (eventAssertion is null || eventAssertion.Invoke(messageEntity)))
                {
                    eventEmitted.TrySetResult(messageEntity);
                }

                return Task.CompletedTask;
            };

        private void RegisterConsumer(Guid correlationId, IDisposable consumer)
        {
            if (_consumersByCorrelationId.TryGetValue(correlationId, out var consumers))
            {
                consumers.Add(consumer);
            } else
            {
                _consumersByCorrelationId.Add(correlationId, new List<IDisposable> { consumer });
            }
        }

        public void DisposeConsumers(Guid correlationId)
        {
            if (_consumersByCorrelationId.TryGetValue(correlationId, out var consumers))
            {
                foreach (var consumer in consumers)
                {
                    consumer.Dispose();
                }
            }
        }
    }
}