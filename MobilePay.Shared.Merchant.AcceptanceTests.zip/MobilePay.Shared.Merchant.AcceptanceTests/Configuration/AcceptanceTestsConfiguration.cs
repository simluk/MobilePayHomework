﻿using System;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Configuration
{
    public class AcceptanceTestsConfiguration : IAcceptanceTestsConfiguration
    {
        public bool UseTestServer { get; set; }

        public string RestApiHost { get; set; }
        
        public string BoundedContext { get; set; }

        public TimeSpan EventualConsistencyTimeout { get; set; }
        
        public TimeSpan EventualConsistencyTimeBetweenRetries { get; set; }
    }
}