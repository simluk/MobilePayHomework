namespace MobilePay.Shared.Merchant.AcceptanceTests.Configuration
{
    public interface IAppSettings
    {
        string BoundedContext { get; }
    }
}