﻿using System;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Configuration
{
    public interface IAcceptanceTestsConfiguration
    {
        bool UseTestServer { get; }

        string RestApiHost { get; }
        
        TimeSpan EventualConsistencyTimeout { get; }
        
        TimeSpan EventualConsistencyTimeBetweenRetries { get; }
    }
}