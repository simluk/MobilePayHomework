namespace MobilePay.Shared.Merchant.AcceptanceTests.Configuration
{
    public class AppSettings : IAppSettings
    {
        public string BoundedContext { get; set; }
    }
}