﻿using System;
using System.Threading.Tasks;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Act
{
    internal class TestActionBuilder : ITestActionBuilder
    {
        private readonly TestActionAssertionBuilder _testActionAssertionBuilder;

        public TestActionBuilder(TestActionAssertionBuilder testActionAssertionBuilder)
        {
            _testActionAssertionBuilder = testActionAssertionBuilder ?? throw new ArgumentNullException(nameof(testActionAssertionBuilder));
        }
        
        public IAssertableTestAction Build(Guid correlationId, Func<Task> action)
        {
            return new AssertableTestAction(_testActionAssertionBuilder, correlationId, action);
        }
    }
}