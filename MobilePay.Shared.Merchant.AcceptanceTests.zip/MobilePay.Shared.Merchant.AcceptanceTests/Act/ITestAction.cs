﻿using System.Threading.Tasks;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Act
{
    public interface ITestAction
    {
        Task<ActionContext> Execute();
    }
}