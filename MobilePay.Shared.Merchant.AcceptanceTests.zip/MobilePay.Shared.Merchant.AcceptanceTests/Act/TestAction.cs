﻿using System;
using System.Threading.Tasks;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Act
{
    internal class TestAction : ITestAction
    {
        private readonly Func<Task> _action;
        
        protected ActionContext ActionContext { get; }

        public TestAction(Guid correlationId, Func<Task> action)
        {
            ActionContext = new ActionContext(correlationId);
            _action = action ?? throw new ArgumentNullException(nameof(action));
        }
        
        public virtual async Task<ActionContext> Execute()
        {
            await _action();

            return ActionContext;
        }
    }
}