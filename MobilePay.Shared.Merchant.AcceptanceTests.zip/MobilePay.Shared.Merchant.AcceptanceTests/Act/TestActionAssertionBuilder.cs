﻿using System;
using System.Threading.Tasks;
using Db.Messaging.Bus.Message;
using DB.MobilePay.Shared.DeferredMessages.MessageBus;
using DB.MobilePay.Shared.Notifications.Email.Client.Contract;
using MobilePay.Shared.Merchant.AcceptanceTests.Act.Assertions;
using MobilePay.Shared.Merchant.AcceptanceTests.Configuration;
using MobilePay.Shared.Merchant.AcceptanceTests.ExternalServices.DeferredMessages;
using MobilePay.Shared.Merchant.AcceptanceTests.ExternalServices.NotificationService;
using MobilePay.Shared.Merchant.AcceptanceTests.Messaging;
using MobilePay.Shared.Merchant.AcceptanceTests.RetryPolicies;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Act
{
    internal class TestActionAssertionBuilder
    {
        private readonly IAcceptanceTestsConfiguration _configuration;
        private readonly IAppSettings _appSettings;
        private readonly EventAwaiter _eventAwaiter;
        private readonly NotificationServiceMock _notificationServiceMock;
        private readonly DeferredMessagesMock _deferredMessagesMock;
        private readonly EventuallyConsistentRetryPolicy _retryPolicy;

        public TestActionAssertionBuilder(IAppSettings appSettings,
            IAcceptanceTestsConfiguration configuration, 
            EventAwaiter eventAwaiter,
            NotificationServiceMock notificationServiceMock,
            DeferredMessagesMock deferredMessagesMock,
            EventuallyConsistentRetryPolicy retryPolicy)
        {
            _appSettings = appSettings ?? throw new ArgumentNullException(nameof(appSettings));
            _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
            _eventAwaiter = eventAwaiter ?? throw new ArgumentNullException(nameof(eventAwaiter));
            _notificationServiceMock = notificationServiceMock ?? throw new ArgumentNullException(nameof(notificationServiceMock));
            _deferredMessagesMock = deferredMessagesMock ?? throw new ArgumentNullException(nameof(deferredMessagesMock));
            _retryPolicy = retryPolicy ?? throw new ArgumentNullException(nameof(retryPolicy));
        }

        public QueryAssertion CreateQueryAssertion(Func<ActionContext, Task> queryFunc) => 
            new(queryFunc, _retryPolicy.GetRetryPolicy());

        public IntegrationEventAssertion<TIntegrationEvent> CreateIntegrationEventAssertion<TIntegrationEvent>(
            Func<ActionContext, MessageEntity<TIntegrationEvent>, bool> matchesIntegrationEvent,
            Action<ActionContext, MessageEntity<TIntegrationEvent>> assertion = null)
            where TIntegrationEvent : class =>
            new(_configuration, _appSettings, _eventAwaiter, matchesIntegrationEvent, assertion);

        public NoIntegrationEventAssertion<TIntegrationEvent> CreateNoIntegrationEventAssertion<TIntegrationEvent>(
            Func<ActionContext, MessageEntity<TIntegrationEvent>, bool> matchesIntegrationEvent)
            where TIntegrationEvent : class =>
            new (_configuration, _appSettings, _eventAwaiter, matchesIntegrationEvent);
        
        public ExternalEmailAssertion CreateExternalEmailAssertion(Func<ActionContext, SendEmail, bool> matchesMessage, Action<ActionContext, SendEmail> assertion) =>
            new (_notificationServiceMock, matchesMessage, assertion);

        public NoExternalEmailAssertion CreateNoExternalEmailAssertion(Func<ActionContext, SendEmail, bool> matchesMessage) =>
            new (_notificationServiceMock, matchesMessage);
        
        public InternalEmailAssertion CreateInternalEmailAssertion(Func<ActionContext, SendInternalEmail, bool> matchesMessage, Action<ActionContext, SendInternalEmail> assertion) =>
            new (_notificationServiceMock, matchesMessage, assertion);

        public NoInternalEmailAssertion CreateNoInternalEmailAssertion(Func<ActionContext, SendInternalEmail, bool> matchesMessage) =>
            new (_notificationServiceMock, matchesMessage);

        public DeferredMessageAssertion<TDeferredMessage> CreateDeferredMessageAssertion<TDeferredMessage>(
            Func<ActionContext, DeferredMessage, bool> matchesDeferredMessage = null,
            Func<ActionContext, TDeferredMessage, bool> matchesDeserializedMessage = null,
            Action<ActionContext, DeferredMessage> assertDeferredMessage = null,
            Action<ActionContext, TDeferredMessage> assertDeserializedMessage = null) =>
            new(
                _deferredMessagesMock,
                matchesDeferredMessage,
                assertDeferredMessage,
                matchesDeserializedMessage,
                assertDeserializedMessage);
        
        public NoDeferredMessageAssertion<TDeferredMessage> CreateNoDeferredMessageAssertion<TDeferredMessage>(
            Func<ActionContext, DeferredMessage, bool> matchesDeferredMessage = null,
            Func<ActionContext, TDeferredMessage, bool> matchesDeserializedMessage = null) =>
            new (_deferredMessagesMock, matchesDeferredMessage, matchesDeserializedMessage);
    }
}