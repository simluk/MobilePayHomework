﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Db.Messaging.Bus.Message;
using DB.MobilePay.Shared.DeferredMessages.MessageBus;
using DB.MobilePay.Shared.Notifications.Email.Client.Contract;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Act
{
    internal class AssertableTestAction : TestAction, IAssertableTestAction
    {
        private readonly TestActionAssertionBuilder _testActionAssertionBuilder;
        private readonly List<ITestActionAssertion> _assertions = new();
        
        public AssertableTestAction(TestActionAssertionBuilder testActionAssertionBuilder, Guid correlationId, Func<Task> action) : base(correlationId, action)
        {
            _testActionAssertionBuilder = testActionAssertionBuilder ?? throw new ArgumentNullException(nameof(testActionAssertionBuilder));
        }

        public override async Task<ActionContext> Execute()
        {
            foreach (var testActionAssertion in _assertions)
            {
                await testActionAssertion.Prepare(ActionContext);
            }
            
            await base.Execute();

            foreach (var testActionAssertion in _assertions)
            {
                await testActionAssertion.Assert(ActionContext);
            }

            return ActionContext;
        }

        public IAssertableTestAction AndQueryForEventuallyConsistentData(Func<ActionContext, Task> query)
        {
            _assertions.Add(_testActionAssertionBuilder.CreateQueryAssertion(query));
            return this;
        }

        public IAssertableTestAction AndWaitForIntegrationEventToBeSent<TIntegrationEvent>(Action<ActionContext, MessageEntity<TIntegrationEvent>> assertion) 
            where TIntegrationEvent : class
        {
            return AndWaitForIntegrationEventToBeSent((context, entity) => true, assertion);
        }

        public IAssertableTestAction AndWaitForIntegrationEventToBeSent<TIntegrationEvent>(
            Func<ActionContext, MessageEntity<TIntegrationEvent>, bool> matchesIntegrationEvent,
            Action<ActionContext, MessageEntity<TIntegrationEvent>> assertion = null)
            where TIntegrationEvent : class
        {
            _assertions.Add(_testActionAssertionBuilder.CreateIntegrationEventAssertion(matchesIntegrationEvent, assertion));
            return this;
        }

        public IAssertableTestAction AndWaitForIntegrationEventNotToBeSent<TIntegrationEvent>()
            where TIntegrationEvent : class
        {
            return AndWaitForIntegrationEventNotToBeSent<TIntegrationEvent>((context, entity) => true);
        }

        public IAssertableTestAction AndWaitForIntegrationEventNotToBeSent<TIntegrationEvent>(Func<ActionContext, MessageEntity<TIntegrationEvent>, bool> matchesIntegrationEvent)
            where TIntegrationEvent : class
        {
            _assertions.Add(_testActionAssertionBuilder.CreateNoIntegrationEventAssertion(matchesIntegrationEvent));
            return this;
        }

        public IAssertableTestAction AndWaitForExternalEmailToBeSent(Func<ActionContext, SendEmail, bool> matchesMessage, Action<ActionContext, SendEmail> assertion)
        {
            _assertions.Add(_testActionAssertionBuilder.CreateExternalEmailAssertion(matchesMessage, assertion));
            return this;
        }

        public IAssertableTestAction AndWaitForExternalEmailNotToBeSent(Func<ActionContext, SendEmail, bool> matchesMessage)
        {
            _assertions.Add(_testActionAssertionBuilder.CreateNoExternalEmailAssertion(matchesMessage));
            return this;
        }

        public IAssertableTestAction AndWaitForInternalEmailToBeSent(Func<ActionContext, SendInternalEmail, bool> matchesMessage, Action<ActionContext, SendInternalEmail> assertion)
        {
            _assertions.Add(_testActionAssertionBuilder.CreateInternalEmailAssertion(matchesMessage, assertion));
            return this;
        }

        public IAssertableTestAction AndWaitForInternalEmailNotToBeSent(Func<ActionContext, SendInternalEmail, bool> matchesMessage)
        {
            _assertions.Add(_testActionAssertionBuilder.CreateNoInternalEmailAssertion(matchesMessage));
            return this;
        }

        public IAssertableTestAction AndWaitForDeferredMessage<TDeferredMessage>(Func<ActionContext, TDeferredMessage, bool> matchesMessage)
        {
            return AndWaitForDeferredMessage((context, message) => true, matchesMessage);
        }

        public IAssertableTestAction AndWaitForDeferredMessage<TDeferredMessage>(
            Func<ActionContext, DeferredMessage, bool> matchesDeferredMessage = null, 
            Func<ActionContext, TDeferredMessage, bool> matchesDeserializedMessage = null,
            Action<ActionContext, DeferredMessage> assertDeferredMessage = null,
            Action<ActionContext, TDeferredMessage> assertDeserializedMessage = null)
        {
            _assertions.Add(_testActionAssertionBuilder.CreateDeferredMessageAssertion(
                matchesDeferredMessage,
                matchesDeserializedMessage,
                assertDeferredMessage,
                assertDeserializedMessage));
            
            return this;
        }

        public IAssertableTestAction AndWaitForDeferredMessageNotToBeSent<TDeferredMessage>(Func<ActionContext, TDeferredMessage, bool> matchesMessage)
        {
            return AndWaitForDeferredMessageNotToBeSent((context, message) => true, matchesMessage);
        }

        public IAssertableTestAction AndWaitForDeferredMessageNotToBeSent<TDeferredMessage>(
            Func<ActionContext, DeferredMessage, bool> matchesDeferredMessage = null, 
            Func<ActionContext, TDeferredMessage, bool> matchesDeserializedMessage = null)
        {
            _assertions.Add(_testActionAssertionBuilder.CreateNoDeferredMessageAssertion(matchesDeferredMessage, matchesDeserializedMessage));
            return this;
        }
    }
}