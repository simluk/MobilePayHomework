﻿using System;
using System.Threading.Tasks;
using Db.Messaging.Bus.Message;
using DB.MobilePay.Shared.DeferredMessages.MessageBus;
using DB.MobilePay.Shared.Notifications.Email.Client.Contract;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Act
{
    public interface IAssertableTestAction : ITestAction
    {
        IAssertableTestAction AndQueryForEventuallyConsistentData(Func<ActionContext, Task> query);

        IAssertableTestAction AndWaitForIntegrationEventToBeSent<TIntegrationEvent>(Action<ActionContext, MessageEntity<TIntegrationEvent>> assertion)
            where TIntegrationEvent : class;

        IAssertableTestAction AndWaitForIntegrationEventToBeSent<TIntegrationEvent>(
            Func<ActionContext, MessageEntity<TIntegrationEvent>, bool> matchesIntegrationEvent,
            Action<ActionContext, MessageEntity<TIntegrationEvent>> assertion = null)
            where TIntegrationEvent : class;

        IAssertableTestAction AndWaitForIntegrationEventNotToBeSent<TIntegrationEvent>()
            where TIntegrationEvent : class;

        IAssertableTestAction AndWaitForIntegrationEventNotToBeSent<TIntegrationEvent>(Func<ActionContext, MessageEntity<TIntegrationEvent>, bool> matchesIntegrationEvent)
            where TIntegrationEvent : class;

        IAssertableTestAction AndWaitForExternalEmailToBeSent(Func<ActionContext, SendEmail, bool> matchesMessage, Action<ActionContext, SendEmail> assertion);

        IAssertableTestAction AndWaitForInternalEmailToBeSent(Func<ActionContext, SendInternalEmail, bool> matchesMessage, Action<ActionContext, SendInternalEmail> assertion);

        IAssertableTestAction AndWaitForExternalEmailNotToBeSent(Func<ActionContext, SendEmail, bool> matchesMessage);

        IAssertableTestAction AndWaitForInternalEmailNotToBeSent(Func<ActionContext, SendInternalEmail, bool> matchesMessage);

        IAssertableTestAction AndWaitForDeferredMessage<TDeferredMessage>(Func<ActionContext, TDeferredMessage, bool> matchesMessage);

        IAssertableTestAction AndWaitForDeferredMessage<TDeferredMessage>(
            Func<ActionContext, DeferredMessage, bool> matchesDeferredMessage = null,
            Func<ActionContext, TDeferredMessage, bool> matchesDeserializedMessage = null,
            Action<ActionContext, DeferredMessage> assertDeferredMessage = null,
            Action<ActionContext, TDeferredMessage> assertDeserializedMessage = null);
        
        IAssertableTestAction AndWaitForDeferredMessageNotToBeSent<TDeferredMessage>(Func<ActionContext, TDeferredMessage, bool> matchesMessage);
        
        IAssertableTestAction AndWaitForDeferredMessageNotToBeSent<TDeferredMessage>(
            Func<ActionContext, DeferredMessage, bool> matchesDeferredMessage = null,
            Func<ActionContext, TDeferredMessage, bool> matchesDeserializedMessage = null);
    }
}