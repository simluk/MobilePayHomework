using System;
using System.Threading.Tasks;
using Polly;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Act.Assertions
{
    internal class QueryAssertion : ITestActionAssertion
    {
        private readonly Func<ActionContext, Task> _assertion;
        private readonly IAsyncPolicy _retryPolicy;

        public QueryAssertion(Func<ActionContext, Task> assertion, IAsyncPolicy retryPolicy)
        {
            _retryPolicy = retryPolicy;
            _assertion = assertion;
        }
        
        public Task Prepare(ActionContext actionContext) => Task.CompletedTask;

        public async Task Assert(ActionContext actionContext)
        {
            await _retryPolicy.ExecuteAsync(
                async () =>
                {
                    await _assertion(actionContext);
                });
        }
    }
}