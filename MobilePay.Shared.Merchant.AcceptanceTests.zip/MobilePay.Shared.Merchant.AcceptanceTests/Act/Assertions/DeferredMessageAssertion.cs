using System;
using System.Threading.Tasks;
using DB.MobilePay.Shared.DeferredMessages.MessageBus;
using MobilePay.Shared.Merchant.AcceptanceTests.ExternalServices.DeferredMessages;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Act.Assertions
{
    internal class DeferredMessageAssertion<TDeferredMessage> : ITestActionAssertion
    {
        private readonly DeferredMessagesMock _deferredMessagesMock;
        private readonly Func<ActionContext, TDeferredMessage, bool> _matchesDeserializedMessage;
        private readonly Action<ActionContext, TDeferredMessage> _assertDeserializedMessage;
        private readonly Func<ActionContext, DeferredMessage, bool> _matchesDeferredMessage;
        private readonly Action<ActionContext, DeferredMessage> _assertDeferredMessage;

        public DeferredMessageAssertion(
            DeferredMessagesMock deferredMessagesMock,
            Func<ActionContext, DeferredMessage, bool> matchesDeferredMessage,
            Action<ActionContext, DeferredMessage> assertDeferredMessage,
            Func<ActionContext, TDeferredMessage, bool> matchesDeserializedMessage,
            Action<ActionContext, TDeferredMessage> assertDeserializedMessage)
        {
            _deferredMessagesMock = deferredMessagesMock;
            _matchesDeferredMessage = matchesDeferredMessage ?? ((context, message) => true);
            _assertDeferredMessage = assertDeferredMessage;
            _matchesDeserializedMessage = matchesDeserializedMessage ?? ((context, message) => true);
            _assertDeserializedMessage = assertDeserializedMessage;
        }
        
        public Task Prepare(ActionContext actionContext) => Task.CompletedTask;

        public async Task Assert(ActionContext actionContext)
        {
            var (deserializedDeferredMessage, deferredMessage) = await _deferredMessagesMock.WaitForDeferredMessage(
                actionContext,
                _matchesDeferredMessage,
                _matchesDeserializedMessage);

            _assertDeferredMessage?.Invoke(actionContext, deferredMessage.Message);
            _assertDeserializedMessage?.Invoke(actionContext, deserializedDeferredMessage);

            actionContext.Store(deserializedDeferredMessage);
            actionContext.Store(deferredMessage.Message);
            actionContext.Store(deferredMessage);
        }
    }
}