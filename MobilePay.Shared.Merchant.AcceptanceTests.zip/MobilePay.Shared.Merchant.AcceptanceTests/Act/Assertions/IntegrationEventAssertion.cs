using System;
using System.Threading.Tasks;
using Db.Messaging.Bus.Message;
using MobilePay.Shared.Merchant.AcceptanceTests.Configuration;
using MobilePay.Shared.Merchant.AcceptanceTests.Extensions;
using MobilePay.Shared.Merchant.AcceptanceTests.Messaging;
using MobilePay.Shared.Merchant.AcceptanceTests.Utilities;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Act.Assertions
{
    internal class IntegrationEventAssertion<TIntegrationEvent> : ITestActionAssertion
        where TIntegrationEvent : class
    {
        private readonly EventAwaiter _eventAwaiter;
        private readonly Func<ActionContext, MessageEntity<TIntegrationEvent>, bool> _matchesIntegrationEvent;
        private readonly IAppSettings _appSettings;
        private readonly IAcceptanceTestsConfiguration _configuration;
        private readonly Action<ActionContext, MessageEntity<TIntegrationEvent>> _assertion;
        private TaskCompletionSource<MessageEntity<TIntegrationEvent>> _completionSource;

        public IntegrationEventAssertion(IAcceptanceTestsConfiguration configuration,
            IAppSettings appSettings,
            EventAwaiter eventAwaiter, 
            Func<ActionContext, MessageEntity<TIntegrationEvent>, bool> matchesIntegrationEvent,
            Action<ActionContext, MessageEntity<TIntegrationEvent>> assertion)
        {
            _configuration = configuration;
            _eventAwaiter = eventAwaiter;
            _matchesIntegrationEvent = matchesIntegrationEvent;
            _appSettings = appSettings;
            _assertion = assertion;
        }

        public Task Prepare(ActionContext actionContext)
        {
            var eventName = HelperMethods.GetIntegrationEventName<TIntegrationEvent>(actionContext.CorrelationId);

            _completionSource = _eventAwaiter.WaitForEvent<TIntegrationEvent>(
                actionContext.CorrelationId,
                _appSettings.BoundedContext,
                eventName, 
                entity => _matchesIntegrationEvent(actionContext, entity));
            
            return Task.CompletedTask;
        }

        public async Task Assert(ActionContext actionContext)
        {
            var integrationEvent = await _completionSource.WaitForEvent(
                _configuration.EventualConsistencyTimeout, 
                $"Did not receive {typeof(TIntegrationEvent).Name} with CorrelationId: {actionContext.CorrelationId}");

            _assertion?.Invoke(actionContext, integrationEvent);

            actionContext.Store(integrationEvent);     
        }
    }
}