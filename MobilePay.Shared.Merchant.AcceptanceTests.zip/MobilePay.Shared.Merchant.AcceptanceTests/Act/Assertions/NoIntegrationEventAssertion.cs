using System;
using System.Threading.Tasks;
using Db.Messaging.Bus.Message;
using MobilePay.Shared.Merchant.AcceptanceTests.Configuration;
using MobilePay.Shared.Merchant.AcceptanceTests.Extensions;
using MobilePay.Shared.Merchant.AcceptanceTests.Messaging;
using MobilePay.Shared.Merchant.AcceptanceTests.Utilities;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Act.Assertions
{
    internal class NoIntegrationEventAssertion<TIntegrationEvent> : ITestActionAssertion
        where TIntegrationEvent : class
    {
        private readonly EventAwaiter _eventAwaiter;
        private readonly Func<ActionContext, MessageEntity<TIntegrationEvent>, bool> _matchesIntegrationEvent;
        private readonly IAppSettings _appSettings;
        private readonly IAcceptanceTestsConfiguration _configuration;
        private TaskCompletionSource<MessageEntity<TIntegrationEvent>> _completionSource;

        public NoIntegrationEventAssertion(
            IAcceptanceTestsConfiguration configuration,
            IAppSettings appSettings,
            EventAwaiter eventAwaiter,
            Func<ActionContext, MessageEntity<TIntegrationEvent>, bool> matchesIntegrationEvent)
        {
            _appSettings = appSettings;
            _eventAwaiter = eventAwaiter;
            _matchesIntegrationEvent = matchesIntegrationEvent;
            _configuration = configuration;
        }

        public Task Prepare(ActionContext actionContext)
        {
            var eventName = HelperMethods.GetIntegrationEventName<TIntegrationEvent>(actionContext.CorrelationId);

            _completionSource = _eventAwaiter.WaitForEvent<TIntegrationEvent>(
                actionContext.CorrelationId,
                _appSettings.BoundedContext,
                eventName,
                entity => _matchesIntegrationEvent(actionContext, entity));

            return Task.CompletedTask;
        }

        public async Task Assert(ActionContext actionContext)
        {
            await Xunit.Assert.ThrowsAsync<TimeoutException>(async () => 
                await _completionSource.WaitForEvent(_configuration.EventualConsistencyTimeout, 
                    $"Did not receive {typeof(TIntegrationEvent).Name} with CorrelationId: {actionContext.CorrelationId}")
            );
        }
    }
}