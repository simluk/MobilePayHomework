using System;
using System.Threading.Tasks;
using DB.MobilePay.Shared.Notifications.Email.Client.Contract;
using MobilePay.Shared.Merchant.AcceptanceTests.ExternalServices.NotificationService;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Act.Assertions
{
    internal class NoInternalEmailAssertion : ITestActionAssertion
    {
        private readonly NotificationServiceMock _notificationServiceMock;
        private readonly Func<ActionContext, SendInternalEmail, bool> _matchesEmail;

        public NoInternalEmailAssertion(NotificationServiceMock notificationServiceMock, Func<ActionContext, SendInternalEmail, bool> matchesEmail)
        {
            _notificationServiceMock = notificationServiceMock;
            _matchesEmail = matchesEmail;
        }
        
        public Task Prepare(ActionContext actionContext) => Task.CompletedTask;

        public async Task Assert(ActionContext actionContext)
        {
            await Xunit.Assert.ThrowsAsync<TimeoutException>(() => _notificationServiceMock.WaitForInternalEmail(actionContext, _matchesEmail));
        }
    }
}