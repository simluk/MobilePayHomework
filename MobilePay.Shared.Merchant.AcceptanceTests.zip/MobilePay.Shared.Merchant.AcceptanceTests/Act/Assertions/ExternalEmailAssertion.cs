using System;
using System.Threading.Tasks;
using DB.MobilePay.Shared.Notifications.Email.Client.Contract;
using MobilePay.Shared.Merchant.AcceptanceTests.ExternalServices.NotificationService;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Act.Assertions
{
    internal class ExternalEmailAssertion : ITestActionAssertion
    {
        private readonly NotificationServiceMock _notificationServiceMock;
        private readonly Func<ActionContext, SendEmail, bool> _matchesEmail;
        private readonly Action<ActionContext, SendEmail> _assertion;

        public ExternalEmailAssertion(NotificationServiceMock notificationServiceMock, Func<ActionContext, SendEmail, bool> matchesEmail, Action<ActionContext, SendEmail> assertion)
        {
            _notificationServiceMock = notificationServiceMock;
            _matchesEmail = matchesEmail;
            _assertion = assertion;
        }
            
        public Task Prepare(ActionContext actionContext) => Task.CompletedTask;

        public async Task Assert(ActionContext actionContext)
        { 
            var email = await _notificationServiceMock.WaitForExternalEmail(actionContext, _matchesEmail);

            _assertion(actionContext, email);

            actionContext.Store(email);
        }
    }
}