using System;
using System.Threading.Tasks;
using DB.MobilePay.Shared.Notifications.Email.Client.Contract;
using MobilePay.Shared.Merchant.AcceptanceTests.ExternalServices.NotificationService;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Act.Assertions
{
    internal class NoExternalEmailAssertion : ITestActionAssertion
    {
        private readonly NotificationServiceMock _notificationServiceMock;
        private readonly Func<ActionContext, SendEmail, bool> _matchesEmail;

        public NoExternalEmailAssertion(NotificationServiceMock notificationServiceMock, Func<ActionContext, SendEmail, bool> matchesEmail)
        {
            _notificationServiceMock = notificationServiceMock;
            _matchesEmail = matchesEmail;
        }
        
        public Task Prepare(ActionContext actionContext) => Task.CompletedTask;

        public async Task Assert(ActionContext actionContext)
        {
            await Xunit.Assert.ThrowsAsync<TimeoutException>(() => _notificationServiceMock.WaitForExternalEmail(actionContext, _matchesEmail));
        }
    }
}