using System;
using System.Threading.Tasks;
using DB.MobilePay.Shared.DeferredMessages.MessageBus;
using MobilePay.Shared.Merchant.AcceptanceTests.ExternalServices.DeferredMessages;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Act.Assertions
{
    public class NoDeferredMessageAssertion<TDeferredMessage> : ITestActionAssertion
    {
        private readonly DeferredMessagesMock _deferredMessagesMock;
        private readonly Func<ActionContext, TDeferredMessage, bool> _matchesDeserializedMessage;
        private readonly Func<ActionContext, DeferredMessage, bool> _matchesDeferredMessage;
        
        public NoDeferredMessageAssertion(
            DeferredMessagesMock deferredMessagesMock,
            Func<ActionContext, DeferredMessage, bool> matchesDeferredMessage = null,
            Func<ActionContext, TDeferredMessage, bool> matchesDeserializedMessage = null)
        {
            _deferredMessagesMock = deferredMessagesMock;
            _matchesDeferredMessage = matchesDeferredMessage ?? ((context, message) => true);
            _matchesDeserializedMessage = matchesDeserializedMessage ?? ((context, message) => true);
        }

        public Task Prepare(ActionContext actionContext) => Task.CompletedTask;

        public async Task Assert(ActionContext actionContext)
        {
            await Xunit.Assert.ThrowsAsync<TimeoutException>(
                async () =>
                    await _deferredMessagesMock.WaitForDeferredMessage(actionContext, _matchesDeferredMessage, _matchesDeserializedMessage));
        }
    }
}