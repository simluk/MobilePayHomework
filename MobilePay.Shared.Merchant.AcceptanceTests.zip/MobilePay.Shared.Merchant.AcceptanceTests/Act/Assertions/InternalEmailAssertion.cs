using System;
using System.Threading.Tasks;
using DB.MobilePay.Shared.Notifications.Email.Client.Contract;
using MobilePay.Shared.Merchant.AcceptanceTests.ExternalServices.NotificationService;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Act.Assertions
{
    internal class InternalEmailAssertion : ITestActionAssertion
    {
        private readonly NotificationServiceMock _notificationServiceMock;
        private readonly Func<ActionContext, SendInternalEmail, bool> _matchesEmail;
        private readonly Action<ActionContext, SendInternalEmail> _assertion;

        public InternalEmailAssertion(NotificationServiceMock notificationServiceMock, Func<ActionContext, SendInternalEmail, bool> matchesEmail, Action<ActionContext, SendInternalEmail> assertion)
        {
            _notificationServiceMock = notificationServiceMock;
            _matchesEmail = matchesEmail;
            _assertion = assertion;
        }
            
        public Task Prepare(ActionContext actionContext) => Task.CompletedTask;

        public async Task Assert(ActionContext actionContext)
        { 
            var email = await _notificationServiceMock.WaitForInternalEmail(actionContext, _matchesEmail);

            _assertion(actionContext, email);

            actionContext.Store(email);
        }
    }
}