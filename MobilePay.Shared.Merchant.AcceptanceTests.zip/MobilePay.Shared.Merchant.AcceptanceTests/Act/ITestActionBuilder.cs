﻿using System;
using System.Threading.Tasks;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Act
{
    public interface ITestActionBuilder
    {
        IAssertableTestAction Build(Guid correlationId, Func<Task> action);
    }
}