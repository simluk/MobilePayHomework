using System;
using System.Collections.Generic;
using System.Linq;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Act
{
    public class ActionContext
    {
        public Guid CorrelationId { get; }

        private readonly Dictionary<Type, object> _results; 

        public ActionContext(Guid correlationId)
        {
            _results = new Dictionary<Type, object>();
            CorrelationId = correlationId;
        }

        public void Store<TResult>(TResult result)
        {
            if (_results.TryGetValue(typeof(TResult), out var existingCollection))
            {
                ((ICollection<TResult>) existingCollection).Add(result);
            }
            else
            {
                var newCollection = new List<TResult> {result};
                _results.Add(typeof(TResult), newCollection);
            }
        }

        public TResult Get<TResult>()
        {
            return GetMultiple<TResult>().Single();
        }

        public IEnumerable<TResult> GetMultiple<TResult>()
        {
            return (ICollection<TResult>) _results[typeof(TResult)];
        }
    }
}