using System.Threading.Tasks;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Act
{
    internal interface ITestActionAssertion
    {
        public Task Prepare(ActionContext actionContext);
        public Task Assert(ActionContext actionContext);
    }
}