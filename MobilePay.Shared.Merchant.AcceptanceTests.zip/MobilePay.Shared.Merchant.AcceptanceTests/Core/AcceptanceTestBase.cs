﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using MobilePay.Shared.Merchant.AcceptanceTests.Act;
using MobilePay.Shared.Merchant.AcceptanceTests.Messaging;

[assembly: ExcludeFromCodeCoverage]

namespace MobilePay.Shared.Merchant.AcceptanceTests.Core
{
    /// <summary>
    /// Base class for the AcceptanceTests. Provides TestWideCorrelationId, helper methods and disposing of the unused queues after test
    /// </summary>
    /// <typeparam name="TFixtureData">Type of the FixtureData used for your tests</typeparam>
    public class AcceptanceTestBase<TFixtureData> : IDisposable
        where TFixtureData : AcceptanceTestFixtureDataBase
    {
        protected readonly TFixtureData FixtureData;
        protected readonly Guid TestWideCorrelationId;
        protected readonly AcceptanceTestHelper AcceptanceTestHelper;
        private readonly EventAwaiter _eventAwaiter;
        private bool _isDisposed;
        
        protected AcceptanceTestBase(TFixtureData fixtureData)
        {
            TestWideCorrelationId = Guid.NewGuid();
            FixtureData = fixtureData;
            AcceptanceTestHelper = GetService<AcceptanceTestHelper>();
            _eventAwaiter = GetService<EventAwaiter>();
        }
        
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        
        protected virtual void Dispose(bool disposing)
        {
            if (_isDisposed)
            {
                return;
            }

            if (disposing)
            {
                _eventAwaiter.DisposeConsumers(TestWideCorrelationId);
            }
            
            _isDisposed = true;
        }

        protected T GetService<T>() => FixtureData.GetRequiredService<T>();
        
        public IAssertableTestAction Act(Guid correlationId, Func<Task> action)
        {
            return AcceptanceTestHelper.Act(correlationId, action);
        }

        public async Task ExecuteWithRetries(Func<Task> action)
        {
            await AcceptanceTestHelper.ExecuteWithRetries(action);
        }

        public async Task RepublishDeferredMessage<TDeferredMessage> (Guid correlationId, Predicate<TDeferredMessage> matchesMessage)
            where TDeferredMessage : class
        {
            await AcceptanceTestHelper.RepublishDeferredMessage(correlationId, matchesMessage);
        }
    }
}