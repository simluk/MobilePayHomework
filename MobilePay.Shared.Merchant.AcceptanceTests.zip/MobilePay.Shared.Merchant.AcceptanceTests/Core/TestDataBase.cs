using System;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Core
{
    public class TestDataBase
    {
        private readonly Guid _correlationId;

        protected TestDataBase() : this(Guid.NewGuid())
        {
        }

        protected TestDataBase(Guid correlationId)
        {
            _correlationId = correlationId;
        }

        public Guid CorrelationId => _correlationId == Guid.Empty ? throw new InvalidOperationException("CorrelationId not set!") : _correlationId;
    }
}