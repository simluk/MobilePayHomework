using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using MobilePay.Shared.Merchant.AcceptanceTests.Act;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Core
{
    /// <summary>
    /// Base class for your test data builders. Provides helpful methods and builder pattern implementation
    /// </summary>
    /// <typeparam name="TTestData"></typeparam>
    public class TestDataBuilderBase<TTestData> where TTestData : TestDataBase
    {
        protected readonly IServiceProvider ServiceProvider;

        protected readonly AcceptanceTestHelper AcceptanceTestHelper;
        
        protected HttpServerMock.HttpServerMock HttpServerMock;

        protected ICollection<Func<Task>> SetupTasks { get; }

        private readonly TTestData _testData;

        protected TTestData TestData
        {
            get => _testData ?? throw new InvalidOperationException("Test Data not Initialized!");
            init => _testData = value;
        }

        protected TestDataBuilderBase(IServiceProvider serviceProvider) : this(serviceProvider, new List<Func<Task>>())
        {
        }

        protected TestDataBuilderBase(IServiceProvider serviceProvider, ICollection<Func<Task>> setupTasks)
        {
            SetupTasks = setupTasks;
            
            ServiceProvider = serviceProvider;
            HttpServerMock = serviceProvider.GetService<HttpServerMock.HttpServerMock>();
            AcceptanceTestHelper = serviceProvider.GetService<AcceptanceTestHelper>();
        }

        public async Task<TTestData> Apply()
        {
            foreach (var setupTask in SetupTasks)
            {
                await setupTask();
            }

            return TestData;
        }
        
        public IAssertableTestAction Act(Guid correlationId, Func<Task> action)
        {
            return AcceptanceTestHelper.Act(correlationId, action);
        }

        public async Task ExecuteWithRetries(Func<Task> action)
        {
            await AcceptanceTestHelper.ExecuteWithRetries(action);
        }
        
        public async Task RepublishDeferredMessage<TDeferredMessage> (Guid correlationId, Predicate<TDeferredMessage> matchesMessage)
            where TDeferredMessage : class
        {
            await AcceptanceTestHelper.RepublishDeferredMessage(correlationId, matchesMessage);
        }

        protected TestDataBuilderBase<TTestData> Setup(Func<Task> setupTask)
        {
            SetupTasks.Add(setupTask);
            return this;
        }
    }
}