﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using Db.Messaging.Bus.Convention.Configuration;
using Db.Messaging.Bus.DependencyInjection;
using Db.Messaging.Bus.MessageBus;
using DB.MobilePay.Shared.Logging.Extensions;
using DB.MobilePay.Shared.Monitoring.Extensions;
using JustEat.StatsD;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using MobilePay.Shared.HttpServerMock;
using MobilePay.Shared.Merchant.AcceptanceTests.Act;
using MobilePay.Shared.Merchant.AcceptanceTests.Configuration;
using MobilePay.Shared.Merchant.AcceptanceTests.ExternalServices.DeferredMessages;
using MobilePay.Shared.Merchant.AcceptanceTests.ExternalServices.NotificationService;
using MobilePay.Shared.Merchant.AcceptanceTests.Http.ClientFactories;
using MobilePay.Shared.Merchant.AcceptanceTests.Http.Clients;
using MobilePay.Shared.Merchant.AcceptanceTests.Http.DelegatingHandlers;
using MobilePay.Shared.Merchant.AcceptanceTests.Messaging;
using MobilePay.Shared.Merchant.AcceptanceTests.RetryPolicies;
using Serilog;
using Xunit;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Core;

public abstract class AcceptanceTestFixtureDataBase : IAsyncLifetime
{
    public ServiceProvider ServiceProvider { get; private set; }

    public async Task InitializeAsync()
    {
        ServiceProvider = CreateServiceCollection();
        await WaitForHostsToStart();
    }

    public async Task DisposeAsync()
    {
        await ServiceProvider.DisposeAsync();
    }

    public T GetRequiredService<T>() => ServiceProvider.GetRequiredService<T>();

    private ServiceProvider CreateServiceCollection()
    {
        var configuration = new ConfigurationBuilder()
            .AddJsonFile("appsettings.json")
            .Build();

        var services = new ServiceCollection()
            .AddSerilogLogger()
            .AddSingleton<IConfiguration>(configuration)
            .AddMessageBusConfiguration()
            .AddBusConfigurationBuilder()
            .AddMessageBusFactory()
            .AddStatsD()
            .AddStatsDClient()
            .AddSingleton(
                provider =>
                    provider
                        .GetRequiredService<IMessageBusFactory>()
                        .Create(provider.GetRequiredService<BusConfigurationBuilder>().Build()))
            .AddSingleton<EventAwaiter>()
            .AddSingleton<DelegatingHandler, SerilogLoggingHandler>()
            .AddTransient<FluentHttpClient>()
            .AddTransient<StatusHttpClient>()
            .AddTransient<IntegrationEventHttpClient>()
            .AddTransient<EventuallyConsistentRetryPolicy>()
            .AddTransient<AcceptanceTestHelper>()
            .AddSingleton<DeferredMessagesMock>()
            .AddSingleton<NotificationServiceMock>()
            .AddTransient<ITestActionBuilder, TestActionBuilder>()
            .AddTransient<TestActionAssertionBuilder>();

        RegisterTestConfiguration(services, configuration);
        RegisterConsumer(services, configuration);
        RegisterWebApplication(services, configuration);
        RegisterCustomDependencies(services, configuration);

        var mockServerConfiguration = configuration.GetSection(nameof(HttpServerMockConfiguration));
        if (mockServerConfiguration.Get<HttpServerMockConfiguration>() != null)
        {
            services
                .Configure<HttpServerMockConfiguration>(mockServerConfiguration)
                .AddSingleton(
                    x => new HttpServerMock.HttpServerMock(
                        x.GetRequiredService<ILogger>().ForContext<HttpServerMock.HttpServerMock>(),
                        x.GetRequiredService<IOptions<HttpServerMockConfiguration>>()));
        }

        services
            .AddHttpClient<AcceptanceTestFixtureDataBase>(
                (provider, client) =>
                    client.BaseAddress = new Uri(provider.GetRequiredService<IAcceptanceTestsConfiguration>().RestApiHost));

        services
            .AddSingleton(provider => provider.GetRequiredService<IRestApiHttpClientFactory>().Create());

        return services
            .BuildServiceProvider();
    }

    private async Task WaitForHostsToStart()
    {
        await RunDbUp();
        if (!ServiceProvider.GetRequiredService<IAcceptanceTestsConfiguration>().UseTestServer)
        {
            await Task.Delay(TimeSpan.FromSeconds(10));
            return;
        }

        var consumerHost = ServiceProvider.GetService<IHost>();
        if (consumerHost == null)
        {
            return;
        }

        await consumerHost.StartAsync();
    }

    protected abstract IServiceCollection RegisterConsumer(IServiceCollection serviceCollection, IConfigurationRoot configuration);
    protected abstract IServiceCollection RegisterWebApplication(IServiceCollection serviceCollection, IConfigurationRoot configuration);
    protected abstract IServiceCollection RegisterCustomDependencies(IServiceCollection serviceCollection, IConfigurationRoot configuration);

    protected virtual async Task RunDbUp() => await Task.CompletedTask;

    protected virtual IServiceCollection RegisterTestConfiguration(IServiceCollection serviceCollection, IConfigurationRoot configuration)
    {
        return serviceCollection.Configure<AppSettings>(configuration.GetSection(nameof(AppSettings)))
            .AddSingleton<IAppSettings>(provider => GetRequiredService<IOptions<AppSettings>>().Value)
            .Configure<AcceptanceTestsConfiguration>(configuration.GetSection(nameof(AcceptanceTestsConfiguration)))
            .AddSingleton<IAcceptanceTestsConfiguration>(provider => provider.GetRequiredService<IOptions<AcceptanceTestsConfiguration>>().Value);
    }
}