using System;
using System.Threading.Tasks;
using DB.MobilePay.Shared.DeferredMessages.MessageBus;
using MobilePay.Shared.Merchant.AcceptanceTests.Act;
using MobilePay.Shared.Merchant.AcceptanceTests.ExternalServices.DeferredMessages;
using MobilePay.Shared.Merchant.AcceptanceTests.RetryPolicies;
using Polly;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Core
{
    public class AcceptanceTestHelper
    {
        private readonly EventuallyConsistentRetryPolicy _eventuallyConsistentRetryPolicy;
        private readonly DeferredMessagesMock _deferredMessagesMock;
        private readonly ITestActionBuilder _testActionBuilder;

        private IAsyncPolicy RetryPolicy => _eventuallyConsistentRetryPolicy.GetRetryPolicy();
        
        public AcceptanceTestHelper(EventuallyConsistentRetryPolicy eventuallyConsistentRetryPolicy,
            DeferredMessagesMock deferredMessagesMock, 
            ITestActionBuilder testActionBuilder)
        {
            _eventuallyConsistentRetryPolicy = eventuallyConsistentRetryPolicy ?? throw new ArgumentNullException(nameof(eventuallyConsistentRetryPolicy));
            _deferredMessagesMock = deferredMessagesMock;
            _testActionBuilder = testActionBuilder ?? throw new ArgumentNullException(nameof(testActionBuilder));
        }
        
        public IAssertableTestAction Act(Guid correlationId, Func<Task> action)
        {
            return _testActionBuilder.Build(correlationId, action);
        }

        public async Task ExecuteWithRetries(Func<Task> action)
        {
            await RetryPolicy.ExecuteAsync(
                async () =>
                {
                    await action();
                });
        }

        public async Task RepublishDeferredMessage<TDeferredMessage>(Guid correlationId, Predicate<TDeferredMessage> matchesMessage)
            where TDeferredMessage : class
        {
            await RepublishDeferredMessage(correlationId, message => true, matchesMessage);
        }

        public async Task RepublishDeferredMessage<TDeferredMessage>(
            Guid correlationId,
            Predicate<DeferredMessage> matchesDeferredMessage,
            Predicate<TDeferredMessage> matchesDeserializedMessage)
            where TDeferredMessage : class
        {
            await _deferredMessagesMock.RepublishDeferredMessage(correlationId, matchesDeferredMessage, matchesDeserializedMessage);
        }
    }
}