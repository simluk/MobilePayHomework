﻿using System;
using AutoFixture;
using Microsoft.Extensions.DependencyInjection;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Extensions
{
    public static class ServiceProviderExtensions
    {
        public static T Create<T>(this IServiceProvider serviceProvider) =>
            serviceProvider.GetRequiredService<IFixture>().Create<T>();
    }
}