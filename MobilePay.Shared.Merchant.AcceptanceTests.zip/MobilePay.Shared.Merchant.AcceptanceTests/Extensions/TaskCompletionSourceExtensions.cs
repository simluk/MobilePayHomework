using System;
using System.Threading;
using System.Threading.Tasks;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Extensions
{
    public static class TaskCompletionSourceExtensions
    {
        public static async Task<T> WaitForEvent<T>(this TaskCompletionSource<T> source, TimeSpan timeout, string failureMessage)
        {
            try
            {
                return await source.WaitForEvent(timeout);
            }
            catch (TaskCanceledException)
            {
                throw new TimeoutException(failureMessage);
            }
        }
    
        private static async Task<T> WaitForEvent<T>(this TaskCompletionSource<T> source, TimeSpan timeout)
        {
            using var cancellationTokenSource = new CancellationTokenSource(timeout);
            cancellationTokenSource.Token.Register(source.SetCanceled);
            return await source.Task;
        }
    }
}