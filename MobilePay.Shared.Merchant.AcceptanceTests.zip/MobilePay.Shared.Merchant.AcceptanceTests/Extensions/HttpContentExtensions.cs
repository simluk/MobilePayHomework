﻿using System.Net.Http;
using System.Threading.Tasks;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Extensions
{
    public static class HttpContentExtensions
    {
        public static async Task<string> ReadAsStringOrNull(this HttpContent content)
        {
            if (content is null)
            {
                return null;
            }

            return await content.ReadAsStringAsync();
        }
    }
}