using System;
using System.Threading.Tasks;
using Db.Messaging.Bus.Message;
using Db.Messaging.Bus.MessageBus;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Extensions
{
    public static class MessageBusExtensions
    {
        public static async Task PublishEvent<TEvent>(
            this IMessageBus messageBus,
            string boundedContext,
            string eventName,
            TEvent @event,
            int? sequence,
            Guid correlationId)
            where TEvent : class
        {
            var messageProperties = new MessageProperties(
                OriginEnum.NewPlatform,
                DateTimeOffset.Now,
                null,
                correlationId.ToString(),
                sequence);

            await messageBus.PublishAsync(
                new BoundedContextName(boundedContext),
                new EventName(eventName),
                @event,
                messageProperties);
        }
        
        public static async Task PublishEvent<TEvent>(
            this IMessageBus messageBus,
            string boundedContext,
            string eventName,
            TEvent @event,
            int? sequence,
            Guid correlationId,
            MessageProperties messageProperties)
            where TEvent : class
        {
            await messageBus.PublishAsync(
                new BoundedContextName(boundedContext),
                new EventName(eventName),
                @event,
                messageProperties);
        }
    }
}