using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Security.Cryptography.X509Certificates;
using DB.MobilePay.Shared.BearerToken.Authentication.Constants;
using DB.MobilePay.Shared.BearerToken.Authentication.JwtGenerator;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Extensions
{
    public static class HttpMessageHeaderExtensions
    {
        public static void AddSupportToolAuthorization(
            this HttpRequestHeaders httpRequestHeaders, 
            string supportUserName,
            IEnumerable<string> functionGroups = null,
            IEnumerable<Claim> customClaims = null)
        {
            var token = JwtGenerator.GenerateSupportToolToken(
                supportUserName,
                functionGroups?.ToList() ?? new List<string>(),
                customClaims?.ToArray() ?? Array.Empty<Claim>());
            
            httpRequestHeaders.Add("Authorization", $"Bearer {token}");
        }

        public static void AddIntegratorAuthorization(this HttpRequestHeaders httpRequestHeaders, Guid integratorId, IDictionary<string, object> customClaims = null)
        {
            httpRequestHeaders.Add("Authorization", $"Bearer {JwtGenerator.GenerateIntegratorToken(integratorId, GenerateValidCertificate(), customClaims: customClaims)}");
        }

        public static void AddAdminAuthorization(this HttpRequestHeaders httpRequestHeaders, Guid apiKey)
        {
            httpRequestHeaders.Add("Authorization", apiKey.ToString());
        }

        public static void AddMerchantUserAuthorization(
            this HttpRequestHeaders httpRequestHeaders,
            Guid merchantId,
            Guid merchantUserId,
            IEnumerable<string> scopes,
            IEnumerable<Claim> customClaims = null)
        {
            var claims = new Dictionary<string, object> { { "merchant_id", merchantId } };
            if (customClaims != null)
            {
                foreach (var claim in customClaims)
                {
                    claims.Add(claim.Type, claim.Value);
                }
            }

            httpRequestHeaders.Add("Authorization", $"Bearer {JwtGenerator.GenerateToken(scopes.ToList(), merchantUserId, issuer: Issuers.MerchantAuthenticationIssuer, customClaims: claims)}");
        }

        private static X509Certificate2 GenerateValidCertificate()
        {
            const string validCertificateString =
                "MIILIgIBAzCCCt4GCSqGSIb3DQEHAaCCCs8EggrLMIIKxzCCBgAGCSqGSIb3DQEHAaCCBfEEggXtMIIF6TCCBeUGCyqGSIb3DQEMCgECoIIE/jCCBPowHAYKKoZIhvcNAQwBAzAOBAgYrm9abQFWTwICB9AEggTYDJkV5rH3LD4rghCSXQbGsqEku3ngS0cBKUeL7evpsGOr+l1bP/UTKu1JfC1LYyr09TzgBFR3Zb95INtwLetUxxduuYIJCwFdzPnl6e0vqvThJBuofuWLUQ3LpLz8V7wlG9B/pmYiz/GUfpu6SdhMM0GezKmvc9nn+i+MMvZJb88SNOZLR2JAb28abBaA+WCw4dwxxlLbhhOQaPDz1f6pNnJyjxfWEX/DfnWiqrlEuMpPN5/Inw8CxWJwTL6eD2GNGLWrBbJ5adP1bLjvBmn/0XOsBToipCei2hzbxQyxOg0/5ps8F8GDSAz8XpoTA76UcBSO7LlZJZKJJjrICHpAqfbGJP5g4rPsKYpwyjw/QbCct7hBbOAdT1pqc+AK1wAhRIaCv2i2ZECbLCZMVZxArd+mWKuGlI94qG6NsMpSoEl7SplyCvywf7I1pn9V1MvAGg6EGHrmhR+oxOsmsaNnr6gjG5yc6K086nus1cs+Z9GJPf/u66hqGiTaAXpOouWJVgfGRTi51K/sLor7kv3eQzHXGrtI2Zzg+buU7ECaPbSyjUTlZj91zITB2R1Ii7J4lZjcu94qcFGXlQZi4sUcQDxFGIDLG04rtpnkzl9nSutWKEqMG6ADipplSBa03e12hY08r9EK7QDkTch7TlZBXWehpiWUbvAZD+0hVKsSm3jRhLA6LvMBk3TqfnVVwwbbLjOpmtOjyZ3r69NN+oR40PPDBnHsot6kYghhx/vI0dQ1Et8VFQx6setxyhYqwd5+HTRIGvua9kERGo4AV2H3ePv6ZFBMgsYwblVJB7FuxJphGW4Yxwp/8/TSAshh50zVZOOosvMy3mX02rSCFGuS9x6A10wimohZQNJdULa804e3Wues+bFwPCplSioGJKaGPAKfGdfFaq3u2kTM9oNrB8QW5c4oet7/EkPK3vhEzR56hakAL+zHhC+PCEyjFn+lFzHzyYjCWFxzJDz1DzG1XaCBitpgFXNkVeC5e7m/kDHypki3AiaCejTDRElM7DOnZpqe2IPXu0rS4oD9MkYNa+qz/8IttsfmJJXG1brSMrUiJAhJehUvZHqWCEePzfyoqq4i85B6fHnY8evMUF13N6+NeBk5J8TqUVUx4OHbGPjmfsCfV6Ft/83TC+GP6dJ4M35MtzZeawHRh8uw2NgtWwQFYUAs6JMd7fN3Cs8RbVQwCwF7NQa7DkUDlW3yTGJwxUfo08EI/4Q14Ml02/DFFFa9454mjGAHZeMnLhOlA84ZBus/ueWOZVRt1RyZNQteebk6LXc05GWHd1Y1XIrxtVYgJAndD2SzaSg/GjKPCCsU76qfheHTJiEpS8lK+9UJRI90hWhhLSbPpXkrHdUIiEyfYe3Zojyp7IpgGdAbaxOl/wpj3x23CiQPTxssRulHWGrJmcztiRm6QHdPY9e9VzheTXeODmK4OXiXlJybscGni5auwGHKTDrNtOEeFPUQSSdDOwnBA7vMpnu3B2gqDAJoRx1THSBhgdybN5Yri+Agl3fbkYZf9bqg6k3pvnQbQ24E/END5PxXgOCDnid7jz0vBn5l8i2TAyK4OhzXprNcSUX2GJ6gQ497JKGnX5lnPP/2Q0h3LQBgtdOTrmYEBuJELarvJl76YJJXbBU0mg9ak7AFatPTRzGB0zATBgkqhkiG9w0BCRUxBgQEAQAAADBdBgkqhkiG9w0BCRQxUB5OAHQAZQAtADIAYQA1ADcAYwA4AGMAYwAtADIANQBjAGQALQA0ADYAZAAxAC0AOAAwAGMAZgAtADAAOAAxADYAYgA3ADcAMgAwAGUAZABmMF0GCSsGAQQBgjcRATFQHk4ATQBpAGMAcgBvAHMAbwBmAHQAIABTAG8AZgB0AHcAYQByAGUAIABLAGUAeQAgAFMAdABvAHIAYQBnAGUAIABQAHIAbwB2AGkAZABlAHIwggS/BgkqhkiG9w0BBwagggSwMIIErAIBADCCBKUGCSqGSIb3DQEHATAcBgoqhkiG9w0BDAEDMA4ECC3plyC7CfP9AgIH0ICCBHgCyFnwIAMx3Ba36ltO8Q9FMFkHWi8rgN5rTiHVJZq29Min9Gb5B8/uBBeIPv5Qxv67WDKWOjxXN8uUIDXxnkxSvX2DGVyciRW2wyN5XJyu2tyGj6NXlg6uCz+4ukM70ceWENTkhC1spgcvIfNuny6CU64iJpeRcg+DTeJh4oPKobJbIWVXAdwSgod6aPiJx42w9hsH8qO28kicBK64osXsLYw4p4ZvIzY3hY3V4wfn3M99/HunfNUZdby/QzZ6JCFdpkCu771tjxojyKS4E1GCL1xNTgbGEh+DKbZm7nGaiF0kUj9ekdI8zsZyTR5gEfi8ax6hzE5uaBWK3yTtLjYO2Gt0NuSZF8tyrRDqpffjDIAYMMbobuEMa29wkrnNttZl36geFzAjO4I10+T5osT4iwseQUeN03jTkYxz/fFtteWozPf1Bkc5pv93QgmFeBqxnepkQQwW7RnIfXxq4gyVtksTi/+EEiAmkDDqdR8rIbzs+BnODlPvxpdEgjwLI3eItZTsSZpfmP34KKzLGmbW3sDN4dBDdTsrYBq2FcQisoG7vdlPorj8FYsSaIpWnNp9VQfxK1Ibcf260s5Nbo501SNpwPdRVsU+cd/Rl29qWeQu+xdYl+sJdVo/PAxmxuV3v8lZr2Ye+u5CSWKeIbUxmgD4zOkLwvzhcRFBJrUBFOSA6DlxTDWUFaq/SGU9hmBEzIWbvkN1zLdhsWoxG9d+N9Rw8qvIqFL+BG9OlNv4NcCYyZQtcEg84IR2wv+CdCg4Sv4NPIzVpk7rEeTfj858JJkzy3Ez6KpJ+9MXLpmLZtsSeEESQOA4zDakAfJdFBFjftQ8O9sEZVYP1w2teOSqgd7kSemtJDoaPtoHzAkLaFe1wk5k0C+PD5ZYkZam35PkN0+Dlq5KaKDhF11F153vfCdFCag+v/lJdwgvjCNAuFH50qXxy1UQHEEGsMyBGTd1jcI9gvhP2VpW+IEmKuL1D/qOKshZ94T4kqDlXoEukugpZMgoRgdBLH/OokGlp5k2a3YHuSaMY3oa+1kRuLZ35kTjk3KVXOr3e2MM3Z5dOVxsd/x5ySULzeUbaS9S4stIQG//lDlMC2aVYrvTS/pwYHdrX/mRejacfq0geBQn6NbkTb9eHUCd0kV187xuSgjeqJ1CC9h9fHIFI7sO/X5whgNIYDWEw31QrjvT0AibRjx7HcgSdRPtkTDIERjThEuVRe94tBN370caKGRqwC6WGEwMAHiPLRGKsseZOvUfsLVTrdw8SwzSfc5pfKC8CDZKv9HZ4upbRNFEdZC4lLO0h+4AQv2OAyvBcBS8bR95XdnMRr5fU5aM+0Tj+zdRuYrPeUKUvreMQraqZo1bA2/7WoahSS4wic4ChpxrAH41VwI7H3ghSmIDIfhQnbshDSgbO77QFbZsI9IVMAs8nQsRI5G/QlLod6RKVfQaZUMbZkKxvTmccYpteNGC7A9SiMfqjyUJlBkHG8c6ol2PauOBUkyL+hLbzvYcZmn/jQyhd01YIkR3w15NMDswHzAHBgUrDgMCGgQUuutXQD/lwqH6X2vj/2N6tJOZ8gYEFM36B2+KHoe6sBGkHW3UDmrf+RzFAgIH0A==";

            const string validCertificatePassword = "1234";
            
            return new(
                Convert.FromBase64String(validCertificateString),
                validCertificatePassword,
                X509KeyStorageFlags.MachineKeySet |
                X509KeyStorageFlags.PersistKeySet |
                X509KeyStorageFlags.Exportable);
        }
    }
}