using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Db.Messaging.Bus.Message;
using Db.Messaging.Bus.MessageBus;
using DB.MobilePay.Shared.DeferredMessages.MessageBus;
using MobilePay.Shared.Merchant.AcceptanceTests.Act;
using MobilePay.Shared.Merchant.AcceptanceTests.Configuration;
using MobilePay.Shared.Merchant.AcceptanceTests.Extensions;
using Newtonsoft.Json;

namespace MobilePay.Shared.Merchant.AcceptanceTests.ExternalServices.DeferredMessages
{
    public class DeferredMessagesMock
    {
        private readonly IAcceptanceTestsConfiguration _acceptanceTestsConfiguration;

        private const string DeferredMessagesBoundedContext = "DeferredMessages";
        private const string DeferredMessageEventName = "DeferredMessage";

        private readonly IMessageBus _messageBus;

        private readonly ConcurrentBag<MessageEntity<DeferredMessage>> _messagesToDefer = new();

        public DeferredMessagesMock(IMessageBus messageBus, IAcceptanceTestsConfiguration acceptanceTestsConfiguration)
        {
            _messageBus = messageBus;
            _acceptanceTestsConfiguration = acceptanceTestsConfiguration;

            SubscribeToDeferredMessages();
        }

        private void SubscribeToDeferredMessages()
        {
            _messageBus.Subscribe<DeferredMessage>(
                DeferredMessagesBoundedContext,
                DeferredMessageEventName,
                x =>
                {
                    if (x.Message.GetType() == typeof(DeferredMessage))
                    {
                        _messagesToDefer.Add(x);
                    }

                    return Task.CompletedTask;
                },
                config =>
                {
                    config.Name = Guid.NewGuid().ToString();
                    config.AutoDelete = true;
                });
        }

        internal async Task<(TDeferredMessage DeserializedMessage, MessageEntity<DeferredMessage> DeferredMessage)> WaitForDeferredMessage<TDeferredMessage>(
            string eventName,
            Guid correlationId,
            Predicate<DeferredMessage> matchesDeferredMessage,
            Predicate<TDeferredMessage> matchesDeserializedMessage)
        {
            var stopwatch = Stopwatch.StartNew();
            while (stopwatch.Elapsed < _acceptanceTestsConfiguration.EventualConsistencyTimeout)
            {
                var deferredMessageAndDeserializedMessage = _messagesToDefer
                    .Where(entity => entity.Properties.CorrelationId == correlationId.ToString() && entity.Message.EventName == eventName && matchesDeferredMessage(entity.Message))
                    .Select(entity => (DeserializedMessage: JsonConvert.DeserializeObject<TDeferredMessage>(entity.Message.SerializedMessage), DeferredMessage: entity))
                    .SingleOrDefault(tuple => matchesDeserializedMessage(tuple.DeserializedMessage));

                if (!deferredMessageAndDeserializedMessage.Equals(default))
                {
                    return deferredMessageAndDeserializedMessage;
                }

                await Task.Delay(TimeSpan.FromMilliseconds(50));
            }

            throw new TimeoutException($"It is impossible to publish deferred message back to the sender, since the sender has not published it yet. CorrelationId: {correlationId}");
        }
        
        internal async Task<(TDeferredMessage DeserializedMessage, MessageEntity<DeferredMessage> DeferredMessage)> WaitForDeferredMessage<TDeferredMessage>(
            string eventName,
            ActionContext actionContext,
            Func<ActionContext, DeferredMessage, bool> matchesDeferredMessage,
            Func<ActionContext, TDeferredMessage, bool> matchesDeserializedMessage)
        {
            return await WaitForDeferredMessage<TDeferredMessage>(
                eventName, 
                actionContext.CorrelationId,
                message => matchesDeferredMessage(actionContext, message),
                message => matchesDeserializedMessage(actionContext, message));
        }
        
        internal async Task<(TDeferredMessage DeserializedMessage, MessageEntity<DeferredMessage> DeferredMessage)> WaitForDeferredMessage<TDeferredMessage>(
            ActionContext actionContext,
            Func<ActionContext, DeferredMessage, bool> matchesDeferredMessage,
            Func<ActionContext, TDeferredMessage, bool> matchesDeserializedMessage)
        {
            return await WaitForDeferredMessage(
                typeof(TDeferredMessage).Name,
                actionContext,
                matchesDeferredMessage,
                matchesDeserializedMessage);
        }

        internal async Task RepublishDeferredMessage<TDeferredMessage>(
            Guid correlationId,
            Predicate<DeferredMessage> matchesDeferredMessage,
            Predicate<TDeferredMessage> matchesDeserializedMessage) where TDeferredMessage : class
        {
            var result = await WaitForDeferredMessage(
                typeof(TDeferredMessage).Name,
                correlationId,
                matchesDeferredMessage,
                matchesDeserializedMessage);
            
            var deferredMessage = result.DeferredMessage;

            await _messageBus.PublishEvent(
                deferredMessage.Message.BoundedContextName,
                deferredMessage.Message.EventName,
                result.DeserializedMessage,
                deferredMessage.Properties.Sequence,
                correlationId);
        }
    }
}