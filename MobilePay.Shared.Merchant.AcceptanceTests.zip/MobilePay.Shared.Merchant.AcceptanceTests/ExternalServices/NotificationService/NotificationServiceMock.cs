﻿using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Db.Messaging.Bus.Message;
using Db.Messaging.Bus.MessageBus;
using DB.MobilePay.Shared.Notifications.Email.Client.Contract;
using MobilePay.Shared.Merchant.AcceptanceTests.Act;
using MobilePay.Shared.Merchant.AcceptanceTests.Configuration;

namespace MobilePay.Shared.Merchant.AcceptanceTests.ExternalServices.NotificationService
{
    internal class NotificationServiceMock
    {
        private readonly IAcceptanceTestsConfiguration _acceptanceTestsConfiguration;
        private const string NotificationServiceBoundedContext = "NotificationService";

        private readonly ConcurrentBag<MessageEntity<SendInternalEmail>> _receivedInternalEmailMessageEntities = new();
        private readonly ConcurrentBag<MessageEntity<SendEmail>> _receivedExternalEmailMessageEntities = new();
        
        public NotificationServiceMock(
            IMessageBus messageBus,
            IAcceptanceTestsConfiguration acceptanceTestsConfiguration)
        {
            _acceptanceTestsConfiguration = acceptanceTestsConfiguration;
            messageBus.RespondAsync<SendInternalEmail>(InternalEmailResponder, NotificationServiceBoundedContext, $"{NotificationServiceBoundedContext}.{nameof(SendInternalEmail)}")
                .GetAwaiter()
                .GetResult();
            
            messageBus.RespondAsync<SendEmail>(ExternalEmailResponder, NotificationServiceBoundedContext, $"{NotificationServiceBoundedContext}.{nameof(SendEmail)}")
                .GetAwaiter()
                .GetResult();
        }

        internal async Task<SendInternalEmail> WaitForInternalEmail(Guid correlationId, Predicate<SendInternalEmail> matchesEmail)
        {
            var stopwatch = Stopwatch.StartNew();
            while (stopwatch.Elapsed < _acceptanceTestsConfiguration.EventualConsistencyTimeout)
            {
                var internalEmail = _receivedInternalEmailMessageEntities.SingleOrDefault(
                    entity => entity.Properties.CorrelationId == correlationId.ToString() && matchesEmail(entity.Message));
                
                if (internalEmail != null)
                {
                    return internalEmail.Message;
                }

                await Task.Delay(TimeSpan.FromMilliseconds(50));
            }

            throw new TimeoutException($"Internal email with correlation id {correlationId} was not received.");
        }
        
        internal async Task<SendInternalEmail> WaitForInternalEmail(ActionContext actionContext, Func<ActionContext, SendInternalEmail, bool> matchesEmail)
        {
            return await WaitForInternalEmail(actionContext.CorrelationId, email => matchesEmail(actionContext, email));
        }

        internal async Task<SendEmail> WaitForExternalEmail(Guid correlationId, Predicate<SendEmail> matchesEmail)
        {
            var stopwatch = Stopwatch.StartNew();
            while (stopwatch.Elapsed < _acceptanceTestsConfiguration.EventualConsistencyTimeout)
            {
                var externalEmail = _receivedExternalEmailMessageEntities.SingleOrDefault(
                    entity => entity.Properties.CorrelationId == correlationId.ToString() && matchesEmail(entity.Message));
                
                if (externalEmail != null)
                {
                    return externalEmail.Message;
                }

                await Task.Delay(TimeSpan.FromMilliseconds(50));
            }

            throw new TimeoutException($"External email with correlation id {correlationId} was not received.");
        }
        
        internal async Task<SendEmail> WaitForExternalEmail(ActionContext actionContext, Func<ActionContext, SendEmail, bool> matchesEmail)
        {
            return await WaitForExternalEmail(actionContext.CorrelationId, email => matchesEmail(actionContext, email));
        }

        private Task InternalEmailResponder(MessageEntity<SendInternalEmail> arg)
        {
            _receivedInternalEmailMessageEntities.Add(arg);
            return Task.CompletedTask;
        }

        private Task ExternalEmailResponder(MessageEntity<SendEmail> arg)
        {
            _receivedExternalEmailMessageEntities.Add(arg);
            return Task.CompletedTask;
        }
    }
}