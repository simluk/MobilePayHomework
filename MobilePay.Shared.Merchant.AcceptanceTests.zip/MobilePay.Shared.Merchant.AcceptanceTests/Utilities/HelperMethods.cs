using System;
using System.Reflection;
using MobilePay.Shared.IntegrationEvent.Attributes;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Utilities
{
    public static class HelperMethods
    {
        public static string GetIntegrationEventName<TIntegrationEvent>(Guid correlationId)
        {
            var integrationEventType = typeof(TIntegrationEvent);

            var eventAttribute = integrationEventType.GetCustomAttribute<IntegrationEventAttribute>();
            if (eventAttribute != null)
            {
                return eventAttribute.EventName;
            }
            
            var eventNameProperty = integrationEventType.GetField("EventName");
            if (eventNameProperty == null)
            {
                eventNameProperty = integrationEventType.GetField("TypeString");
            }

            if (eventNameProperty == null)
            {
                throw new InvalidOperationException($"Unable to find EventName for {typeof(TIntegrationEvent).Name}. CorrelationId: {correlationId}");
            }

            return eventNameProperty.GetRawConstantValue()?.ToString();
        }
    }
}