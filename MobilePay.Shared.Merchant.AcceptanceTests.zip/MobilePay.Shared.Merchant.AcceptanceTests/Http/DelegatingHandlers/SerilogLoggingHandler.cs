﻿using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using MobilePay.Shared.Merchant.AcceptanceTests.Extensions;
using Serilog;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Http.DelegatingHandlers;

public class SerilogLoggingHandler : DelegatingHandler
{
    private readonly ILogger _logger;

    public SerilogLoggingHandler(ILogger logger)
    {
        _logger = logger.ForContext<SerilogLoggingHandler>();
    }

    protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        var path = request.RequestUri?.AbsolutePath;

        _logger.Information(
            "Test client HTTP {Method}, {Path} invoked. Content: {Content}",
            request.Method,
            path,
            request.Content != null && request.Content.IsMimeMultipartContent() ? "Mime multipart content redacted" : await request.Content.ReadAsStringOrNull());

        var response = await base.SendAsync(request, cancellationToken);

        _logger.Information(
            "Test client HTTP {Method}, {Path} responded with {StatusCode}",
            request.Method,
            path,
            $"{response.StatusCode} - {response.StatusCode.ToString()},");

        return response;
    }
}