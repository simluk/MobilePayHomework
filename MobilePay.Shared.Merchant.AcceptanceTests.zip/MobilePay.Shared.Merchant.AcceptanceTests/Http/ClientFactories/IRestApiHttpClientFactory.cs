﻿using System;
using System.Net.Http;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Http.ClientFactories
{
    public interface IRestApiHttpClientFactory : IDisposable
    {
        HttpClient Create();
    }
}