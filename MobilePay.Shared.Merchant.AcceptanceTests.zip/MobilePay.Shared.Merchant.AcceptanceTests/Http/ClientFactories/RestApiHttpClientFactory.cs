﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using Microsoft.AspNetCore.Mvc.Testing;
using MobilePay.Shared.Merchant.AcceptanceTests.Configuration;
using MobilePay.Shared.Merchant.AcceptanceTests.Core;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Http.ClientFactories
{
    public class RestApiHttpClientFactory<TWebApplication> : IRestApiHttpClientFactory
        where TWebApplication : class
    {
        private readonly IAcceptanceTestsConfiguration _acceptanceTestsConfiguration;
        private readonly IEnumerable<DelegatingHandler> DelegatingHandlers;
        private readonly WebApplicationFactory<TWebApplication> WebApplicationFactory;
        private readonly HttpClient _externalClient;
        private readonly Lazy<HttpClient> _inMemoryClient;
        
        public RestApiHttpClientFactory(
            IAcceptanceTestsConfiguration acceptanceTestsConfiguration,
            IEnumerable<DelegatingHandler> delegatingHandlers,
            IHttpClientFactory httpClientFactory,
            WebApplicationFactory<TWebApplication> webApplicationFactory)
        {
            _acceptanceTestsConfiguration = acceptanceTestsConfiguration;
            DelegatingHandlers = delegatingHandlers;
            _externalClient = httpClientFactory.CreateClient(nameof(AcceptanceTestFixtureDataBase));
            WebApplicationFactory = webApplicationFactory;

            _inMemoryClient = new Lazy<HttpClient>(CreateInMemoryClient);
        }
        
        public void Dispose()
        {
            _externalClient?.Dispose();
            
            GC.SuppressFinalize(this);
        }

        public HttpClient Create() => _acceptanceTestsConfiguration.UseTestServer ? _inMemoryClient.Value : _externalClient;
        
        private HttpClient CreateInMemoryClient()
        {
            return WebApplicationFactory.CreateDefaultClient(DelegatingHandlers.ToArray());
        }

    }
}