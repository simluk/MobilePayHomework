using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using MobilePay.Shared.Merchant.AcceptanceTests.Configuration;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Http.Clients
{
    public class IntegrationEventHttpClient : FluentHttpClient
    {
        public IntegrationEventHttpClient(
            HttpClient httpClient,
            IAcceptanceTestsConfiguration acceptanceTestsConfiguration) : base(httpClient)
        {
        }

        public async Task<HttpResponseMessage> GetIntegrationEventsWithoutEnsuringSuccess(Guid correlationId)
        {
            return await CreateGetRequest(correlationId, "api/v1/reconstitution/integrationevent")
                .ExecuteWithoutEnsuringSuccess();
        }
        
        public async Task<IntegrationEventPageReadModel> GetIntegrationEvents(Guid correlationId)
        {
            return await CreateGetRequest(correlationId, "api/v1/reconstitution/integrationevent")
                .ExecuteForResult<IntegrationEventPageReadModel>();
        }
        
        public async Task<HttpResponseMessage> GetAggregateIntegrationEventsWithoutEnsuringSuccess(Guid correlationId, Guid aggregateId)
        {
            return await CreateGetRequest(correlationId, $"api/v1/reconstitution/integrationevent/{aggregateId}")
                .ExecuteWithoutEnsuringSuccess();
        }
        
        public async Task<IEnumerable<IntegrationEventReadModel>> GetAggregateIntegrationEvents(Guid correlationId, Guid aggregateId)
        {
            return await CreateGetRequest(correlationId, $"api/v1/reconstitution/integrationevent/{aggregateId}")
                .ExecuteForResult<IEnumerable<IntegrationEventReadModel>>();
        }
    }
    
    public class IntegrationEventPageReadModel
    {
        public IntegrationEventPageReadModel()
        {
            PagingState = string.Empty;
        }

        public string PagingState { get; set; }

        public List<IntegrationEventReadModel> Page { get; set; }
    }
    
    public class IntegrationEventReadModel
    {
        public Guid Id { get; set; }
        
        public string Data { get; set; }
        
        public string EventType { get; set; }
        
        public int Sequence { get; set; }
        
        public string MetaData { get; set; }
    }
}