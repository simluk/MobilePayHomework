﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Security.Claims;
using System.Threading.Tasks;
using MobilePay.Shared.Merchant.AcceptanceTests.Extensions;
using Newtonsoft.Json.Converters;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Http.Clients
{
    /// <summary>
    /// HttpClient that uses builder pattern to generate generic HTTP requests
    /// </summary>
    public class FluentHttpClient
    {
        /// <summary>
        /// Default support user name to pass to WithSupportToolAuthorization should there be no need for custom user name
        /// </summary>
        public const string DefaultSupportUserName = "acceptance_support_user@mobilepay.dk";

        private readonly HttpClient _httpClient;

        private HttpRequestMessage RequestMessage { get; set; }

        protected FluentHttpClient(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        /// <summary>
        /// Adds headers required for SupportToolAuthorization
        /// </summary>
        /// <param name="supportUserName">email of the supporter</param>
        /// <returns>FluentHttpClient</returns>
        public FluentHttpClient WithSupportToolAuthorization(string supportUserName = DefaultSupportUserName)
        {
            return WithSupportToolAuthorization(supportUserName, customClaims: null, functionGroups: null);
        }

        /// <summary>
        /// Adds headers required for SupportToolAuthorization
        /// </summary>
        /// <param name="supportUserName">email of the supporter</param>
        /// <param name="customClaims">Custom claims to be added, if any</param>
        /// <returns>FluentHttpClient</returns>
        public FluentHttpClient WithSupportToolAuthorization(
            string supportUserName,
            params Claim[] customClaims)
        {
            return WithSupportToolAuthorization(supportUserName, customClaims, functionGroups: null);
        }
        
        /// <summary>
        /// Adds headers required for SupportToolAuthorization
        /// </summary>
        /// <param name="supportUserName">email of the supporter</param>
        /// <param name="functionGroups">Function groups to be included in JWT</param>
        /// <returns>FluentHttpClient</returns>
        public FluentHttpClient WithSupportToolAuthorization(
            string supportUserName,
            params string[] functionGroups)
        {
            return WithSupportToolAuthorization(supportUserName, customClaims: null, functionGroups);
        }

        /// <summary>
        /// Adds headers required for SupportToolAuthorization
        /// </summary>
        /// <param name="supportUserName">email of the supporter</param>
        /// <param name="functionGroups">Function groups to be included in JWT</param>
        /// <param name="customClaims">Custom claims to be added, if any</param>
        /// <returns>FluentHttpClient</returns>
        public FluentHttpClient WithSupportToolAuthorization(
            string supportUserName,
            IEnumerable<Claim> customClaims,
            params string[] functionGroups)
        {
            RequestMessage.Headers.AddSupportToolAuthorization(supportUserName, functionGroups, customClaims);
            return this;
        }

        /// <summary>
        /// Adds headers required for IntegratorAuthorizations
        /// </summary>
        /// <param name="integratorId">IntegratorId</param>
        /// <param name="customClaims">Custom claims to be added, if any</param>
        /// <returns>FluentHttpClient</returns>
        public FluentHttpClient WithIntegratorAuthorization(Guid integratorId, IDictionary<string, object> customClaims = null)
        {
            RequestMessage.Headers.AddIntegratorAuthorization(integratorId, customClaims);
            return this;
        }

        /// <summary>
        /// Adds headers required for MerchantUserAuthorization
        /// </summary>
        /// <param name="merchantId">Id of the merchant</param>
        /// <param name="merchantUserId">Id of the merchant</param>
        /// <param name="scopes">Scopes to be added to the JWT</param>
        /// <param name="customClaims">Custom claims to be added, if any</param>
        /// <returns>FluentHttpClient</returns>
        public FluentHttpClient WithMerchantUserAuthorization(Guid merchantId, Guid merchantUserId, IEnumerable<string> scopes, IEnumerable<Claim> customClaims = null)
        {
            RequestMessage.Headers.AddMerchantUserAuthorization(merchantId, merchantUserId, scopes, customClaims);
            return this;
        }

        /// <summary>
        /// Adds headers required for AdminAuthorization
        /// </summary>
        /// <param name="adminApiKey">API key</param>
        /// <returns>FluentHttpClient</returns>
        public FluentHttpClient WithAdminAuthorization(Guid adminApiKey)
        {
            RequestMessage.Headers.AddAdminAuthorization(adminApiKey);
            return this;
        }

        /// <summary>
        /// Executes the request and returns the response, ensuring the call should succeed. Throws otherwise
        /// </summary>
        /// <returns>HttpResponseMessage</returns>
        public async Task<HttpResponseMessage> Execute()
        {
            var response = await ExecuteWithoutEnsuringSuccess();
            
            response.EnsureSuccessStatusCode();

            return response;
        }
        
        /// <summary>
        /// Executes the request and returns the response,
        /// </summary>
        /// <returns>HttpResponseMessage</returns>
        public async Task<HttpResponseMessage> ExecuteWithoutEnsuringSuccess()
        {
            return await _httpClient.SendAsync(RequestMessage);
        }

        /// <summary>
        /// Executes the request and returns deserialized contents of the response
        /// </summary>
        /// <typeparam name="TResult">Type of the expected responsebody</typeparam>
        /// <returns>Deserialized response body</returns>
        public async Task<TResult> ExecuteForResult<TResult>() 
        {
            var response = await Execute();

            return await response.DeserializeContent<TResult>();
        }

        /// <summary>
        /// Creates a HTTP Get request
        /// </summary>
        /// <param name="correlationId">CorrelationId to be sent with the request (used for logging purposes)</param>
        /// <param name="uri">Relative path of the api endpoint</param>
        /// <returns>FluentHttpClient</returns>
        public FluentHttpClient CreateGetRequest(Guid correlationId, string uri) =>
            CreateRequest(correlationId, uri, HttpMethod.Get); 

        /// <summary>
        /// Creates a HTTP Request
        /// </summary>
        /// <param name="correlationId">CorrelationId to be sent with the request (used for logging purposes)</param>
        /// <param name="uri">Relative path of the api endpoint</param>
        /// <param name="httpMethod">HTTP method to be used</param>
        /// <returns>FluentHttpClient</returns>
        public FluentHttpClient CreateRequest(Guid correlationId, string uri, HttpMethod httpMethod) => 
            CreateRequest<object>(correlationId, uri, httpMethod, null); 
        
        /// <summary>
        /// Creates a HTTP Request with given request body
        /// </summary>
        /// <param name="correlationId">CorrelationId to be sent with the request (used for logging purposes)</param>
        /// <param name="uri">Relative path of the api endpoint</param>
        /// <param name="httpMethod">HTTP method to be used</param>
        /// <param name="content">Object to be serialized and added as request body</param>
        /// <typeparam name="T">Type of the request body</typeparam>
        /// <returns>FluentHttpClient</returns>
        public FluentHttpClient CreateRequest<T>(Guid correlationId, string uri, HttpMethod httpMethod, T content)
        {
            var request = new HttpRequestMessage(httpMethod, uri);
            if (content is not null)
            {
                var formatter = new JsonMediaTypeFormatter();
                formatter.SerializerSettings.Converters.Add(new StringEnumConverter());
                request.Content = new ObjectContent<T>(content, formatter);
            }

            request.Headers.Add("CorrelationId", correlationId.ToString());
            RequestMessage = request;

            return this;
        }

        /// <summary>
        /// Assigns a HTTP Request to a given request.
        /// </summary>
        /// <param name="correlationId">CorrelationId to be sent with the request (used for logging purposes)</param>
        /// <param name="httpRequestMessage">HTTP request message to be used</param>
        /// <returns>FluentHttpClient</returns>
        public FluentHttpClient CreateRequest(Guid correlationId, HttpRequestMessage httpRequestMessage)
        {
            httpRequestMessage.Headers.Add("CorrelationId", correlationId.ToString());
            RequestMessage = httpRequestMessage;

            return this;
        }
        
        /// <summary>
        /// Creates a HTTP Request
        /// </summary>
        /// <param name="correlationId">CorrelationId to be sent with the request (used for logging purposes)</param>
        /// <param name="file">Byte array content of the file and file name</param>
        /// <param name="uri">Relative path of the api endpoint</param>
        /// <param name="httpMethod">HTTP method to be used</param>
        /// <param name="additionalFormContent">Serialized content</param>
        /// <returns>FluentHttpClient</returns>
        public FluentHttpClient CreateFileRequest(
            Guid correlationId,
            (ByteArrayContent byteArrayContent, string name) file,
            string uri,
            HttpMethod httpMethod,
            IEnumerable<(StringContent, string)> additionalFormContent = null)
        {
            const string multipartFormDataPartName = "file";
            var (byteArrayContent, name) = file;
            var formDataContent = new MultipartFormDataContent
            {
                {byteArrayContent, multipartFormDataPartName, name}
            };

            if (additionalFormContent != null)
            {
                foreach (var content in additionalFormContent)
                {
                    if (content != default)
                    {
                        formDataContent.Add(content.Item1, content.Item2);
                    }
                }
            }

            var request = new HttpRequestMessage(HttpMethod.Post, uri)
            {
                Content = formDataContent
            };

            request.Headers.Add("CorrelationId", correlationId.ToString());
            RequestMessage = request;

            return this;
        }
    }
}