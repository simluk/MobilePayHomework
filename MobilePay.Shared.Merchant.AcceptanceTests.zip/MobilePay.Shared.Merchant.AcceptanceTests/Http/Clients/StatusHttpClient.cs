﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using MobilePay.Shared.Merchant.AcceptanceTests.Configuration;

namespace MobilePay.Shared.Merchant.AcceptanceTests.Http.Clients
{
    public class StatusHttpClient : FluentHttpClient
    {
        public StatusHttpClient(
            HttpClient httpClient,
            IAcceptanceTestsConfiguration acceptanceTestsConfiguration) : base(httpClient)
        {
        }
        
        public async Task<HttpResponseMessage> GetShallowHealthCheckWithoutEnsuringSuccess(Guid correlationId)
        {
            return await CreateGetRequest(correlationId, "api/status/shallow")
                .ExecuteWithoutEnsuringSuccess();
        }
        
        public async Task<string> GetShallowHealthCheck(Guid correlationId)
        {
            return await CreateGetRequest(correlationId, "api/status/shallow")
                .ExecuteForResult<string>();
        }

        public async Task<HttpResponseMessage> GetDeepHealthCheckWithoutEnsuringSuccess(Guid correlationId)
        {
            return await CreateGetRequest(correlationId, "api/status/deep")
                .ExecuteWithoutEnsuringSuccess();
        }
        
        public async Task<string> GetDeepHealthCheck(Guid correlationId)
        {
            return await CreateGetRequest(correlationId, "api/status/deep")
                .ExecuteForResult<string>();
        }
    }
}