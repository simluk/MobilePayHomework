using System;
using MobilePay.Shared.Merchant.AcceptanceTests.Configuration;
using Polly;

namespace MobilePay.Shared.Merchant.AcceptanceTests.RetryPolicies
{
    public class EventuallyConsistentRetryPolicy
    {
        private readonly IAcceptanceTestsConfiguration _acceptanceTestsConfiguration;
        private readonly int _retryCount;

        public EventuallyConsistentRetryPolicy(IAcceptanceTestsConfiguration acceptanceTestsConfiguration)
        {
            _acceptanceTestsConfiguration = acceptanceTestsConfiguration;
            _retryCount = (int)(_acceptanceTestsConfiguration.EventualConsistencyTimeout.TotalMilliseconds 
                                / _acceptanceTestsConfiguration.EventualConsistencyTimeBetweenRetries.TotalMilliseconds);
        }
        
        public IAsyncPolicy GetRetryPolicy()
        {
            return Policy
                .Handle<Exception>()
                .WaitAndRetryAsync(_retryCount, SleepDurationProvider);
        }

        private TimeSpan SleepDurationProvider(int retryAttempt) => _acceptanceTestsConfiguration.EventualConsistencyTimeBetweenRetries;
    }
}