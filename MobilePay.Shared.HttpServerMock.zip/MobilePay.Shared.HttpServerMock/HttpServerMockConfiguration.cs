namespace MobilePay.Shared.HttpServerMock
{
    public class HttpServerMockConfiguration
    {
        public string[] BaseUrls { get; set; }
    }
}