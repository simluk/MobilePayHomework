using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace MobilePay.Shared.HttpServerMock
{
    public static class ServiceCollectionExtensions
    {
        /// <summary>
        /// Configures HttpServerMock on the DI Container with a Singleton lifetime. A section named HttpServerMockConfiguration is required to be setup in your acceptance tests appsettings.json
        /// </summary>
        /// <param name="services"></param>
        /// <param name="configuration"></param>
        /// <returns></returns>
        public static IServiceCollection AddHttpServerMock(this IServiceCollection services, IConfiguration configuration)
        {
            services.Configure<HttpServerMockConfiguration>(configuration.GetSection("HttpServerMockConfiguration"));
            services.AddSingleton<HttpServerMock>();

            return services;
        }

        /// <summary>
        /// Configures HttpServerMock on the DI Container with a Singleton lifetime. A pointer to where you store the BaseUrls in the appsettings is required.
        /// </summary>
        /// <param name="services"></param>
        /// <param name="configuration"></param>
        /// <param name="appSettingsKey"></param>
        /// <returns></returns>
        public static IServiceCollection AddHttpServerMock(this IServiceCollection services, IConfiguration configuration, string appSettingsKey)
        {
            var baseUrls = configuration.GetValue<string[]>(appSettingsKey);

            services.AddOptions<HttpServerMockConfiguration>().Configure(x => x.BaseUrls = baseUrls);
            services.AddSingleton<HttpServerMock>();
            
            return services;
        }
    }
}