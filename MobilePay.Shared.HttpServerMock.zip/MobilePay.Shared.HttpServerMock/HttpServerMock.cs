﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Serilog;
using Serilog.Context;

namespace MobilePay.Shared.HttpServerMock
{
    public class HttpServerMock : IAsyncDisposable
    {
        private readonly ILogger _logger;
        private const string DefaultUrl = "http://localhost:1337";

        // Since we need to be able to enumerate elements while modifying the collection, SynchronizedCollection is not good enough
        // ConcurrentBag, on the other hand doesn't allow removal of elements
        // ConcurrentSet would be ideal, but there is no build in implementation in .NET
        // Therefore, ConcurrentDictionary, while a bit ugly
        // Seems like our best bet, since it allows both removal and enumeration while adding/removing elements concurrently
        private readonly ConcurrentDictionary<MockEndpoint, MockEndpoint> _registeredMockEndpoints = new ConcurrentDictionary<MockEndpoint, MockEndpoint>();
        private readonly IWebHost _webHost;

        public readonly List<string> Urls = new List<string>();

        public HttpServerMock(ILogger logger, IOptions<HttpServerMockConfiguration> configuration)
        {
            _logger = logger.ForContext<HttpServerMock>();
            if (configuration.Value.BaseUrls.Any())
                Urls.AddRange(configuration.Value.BaseUrls);
            else
                Urls.Add(DefaultUrl);

            _webHost = new WebHostBuilder()
                .UseKestrel()
                .UseUrls(Urls.ToArray())
                .Configure(app =>
                {
                    app.UseMiddleware<CorrelationIdMiddleware>()
                    .Use(async (context, func) =>
                    {
                        try
                        {
                            _logger.Information($"[HttpServerMock] Hit endpoint {context.Request.Path}");
                            
                            await HandleRequest(context);
                        }
                        catch (Exception e)
                        {
                            _logger.Fatal(e, "Exception caught in HttpServerMock when handling requests");
                            throw;
                        }
                    });
                }).Build();
            _webHost.Start();
        }

        private async Task HandleRequest(HttpContext context)
        {
            var matchingMockEndpoints = await GetMatchingMockEndpoints(context);

            switch (matchingMockEndpoints.Count)
            {
                case 1:
                    var mockEndpoint = matchingMockEndpoints.Single();
                    mockEndpoint.MatchedCount++;
                    await mockEndpoint.Response(context);
                    break;
                case var x when x > 1:
                    var tooManyHandlersMessage = $"Too many handlers found for request {context.Request.Path} - Use a correlation id to make your request and handler unique";
                    _logger.Error(tooManyHandlersMessage);

                    context.Response.StatusCode = (int) HttpStatusCode.ExpectationFailed;
                    await context.Response.WriteAsync($"Too many handlers found for request {context.Request.Path} - Use a correlation id to make your request and handler unique");
                    break;
                default:
                    var handlerNotFoundMessage = $"Could not find handler. Remember to register a handler for request {context.Request.Path}";
                    _logger.Error(handlerNotFoundMessage);
                    
                    context.Response.StatusCode = (int) HttpStatusCode.ExpectationFailed;
                    await context.Response.WriteAsync(handlerNotFoundMessage);
                    break;
            }
        }

        private async Task<List<MockEndpoint>> GetMatchingMockEndpoints(HttpContext context)
        {
            var matchingMockEndpoints = new List<MockEndpoint>();

            foreach (var registeredMockEndpoint in _registeredMockEndpoints.Keys)
            {
                var passedHandlers = new List<Func<HttpContext, ILogger, Task<bool>>>();
                foreach (var handler in registeredMockEndpoint.Handlers)
                {
                    context.Request.EnableBuffering();
                    var handlerResult = await handler(context, _logger);
                    context.Request.Body.Position = 0;

                    if (!handlerResult)
                        break;

                    passedHandlers.Add(handler);
                }

                if (passedHandlers.Count == registeredMockEndpoint.Handlers.Count)
                {
                    matchingMockEndpoints.Add(registeredMockEndpoint);
                }
            }

            return matchingMockEndpoints;
        }

        public void ClearAllRegisteredMockEndPoints()
        {
            _registeredMockEndpoints.Clear();
        }

        public void ClearMockEndPoint(MockEndpoint mockEndpoint)
        {
            _registeredMockEndpoints.Remove(mockEndpoint, out var _);
        }

        public MockEndpoint RegisterMockEndpoint(MockEndpoint mockEndpoint)
        {
            _registeredMockEndpoints[mockEndpoint] = mockEndpoint;

            return mockEndpoint;
        }
        
        public async ValueTask DisposeAsync()
        {
            await DisposeAsyncCore();
            _webHost?.Dispose();
            GC.SuppressFinalize(this);
        }
        
        protected virtual async ValueTask DisposeAsyncCore()
        {
            if (_webHost == null)
            {
                return;
            }
            
            await _webHost.StopAsync().ConfigureAwait(false);
        }
    }
}