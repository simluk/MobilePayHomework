using System;

namespace MobilePay.Shared.HttpServerMock
{
    public class HttpServerMockException : Exception
    {
        public HttpServerMockException()
        {
        }

        public HttpServerMockException(string message)
            : base(message)
        {
        }

        public HttpServerMockException(string message, Exception inner)
            : base(message, inner)
        {
        }
    }
}