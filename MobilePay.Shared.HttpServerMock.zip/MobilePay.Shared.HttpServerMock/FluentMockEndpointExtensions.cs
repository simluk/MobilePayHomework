using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using Serilog;

namespace MobilePay.Shared.HttpServerMock
{
    public static class FluentMockEndpointExtensions
    {
        public static MockEndpoint OnPathEqual(this MockEndpoint mockEndpoint, string path)
        {
            mockEndpoint.Handlers.Add((context, _) =>
            {
                var result = context.Request.Path.Value.Trim('/').Equals(path.Trim('/'));
                
                return Task.FromResult(result);
            });
            return mockEndpoint;
        }
        
        public static MockEndpoint OnPathContains(this MockEndpoint mockEndpoint, string path)
        {
            mockEndpoint.Handlers.Add((context, _) =>
            {
                var result = context.Request.Path.Value.Trim('/').Contains(path.Trim('/'));
                
                return Task.FromResult(result);
            });
            return mockEndpoint;
        }

        public static MockEndpoint OnQueryEquals(this MockEndpoint mockEndpoint, string query)
        {
            mockEndpoint.Handlers.Add((context, _) =>
            {
                var result = context.Request.QueryString.Value.Contains(query);
                
                return Task.FromResult(result);
            });
            return mockEndpoint;
        }

        public static MockEndpoint OnPathQueryEquals(this MockEndpoint mockEndpoint, string pathAndQuery)
        {
            if (!pathAndQuery.StartsWith("http://", StringComparison.OrdinalIgnoreCase))
            {
                pathAndQuery = "http://test/" + pathAndQuery;
            }

            var url = new Uri(pathAndQuery, UriKind.RelativeOrAbsolute);
            mockEndpoint.OnPathEqual(url.LocalPath);
            mockEndpoint.OnQueryEquals(url.Query);
            return mockEndpoint;
        }

        public static MockEndpoint OnMethodEqual(this MockEndpoint mockEndpoint, HttpMethod httpMethod)
        {
            mockEndpoint.Handlers.Add((context, _) =>
            {
                var result = context.Request.Method == httpMethod.ToString();
                return Task.FromResult(result);
            });
            return mockEndpoint;
        }

        public static MockEndpoint OnBodyContains(this MockEndpoint mockEndpoint, string content)
        {
            mockEndpoint.CustomAssert((_, data, _) =>
            {
                var body = data.Body;
                var result = body != null && !string.IsNullOrWhiteSpace(body) && body.Contains(content);
                return Task.FromResult(result);
            });
                
            return mockEndpoint;
        }
        
        public static MockEndpoint CustomAssert(this MockEndpoint mockEndpoint, Func<HttpContext, ILogger, Task<bool>> func)
        {
            mockEndpoint.Handlers.Add(func);
            
            return mockEndpoint;
        }
        
        public static MockEndpoint CustomAssert(this MockEndpoint mockEndpoint, Func<HttpContext, (string Method, string Path, string Body), ILogger, Task<bool>> func)
        {
            mockEndpoint.Handlers.Add(async (context, logger) =>
            {
                var request = context.Request;
                using var reader = new StreamReader(request.Body, leaveOpen: true);
                var bodyStr = await reader.ReadToEndAsync();
                
                return await func(context, (request.Method, request.Path.ToString().TrimStart('/'), bodyStr), logger);
            });
            
            return mockEndpoint;
        }
        
        public static MockEndpoint CustomAssert<TBodyType>(this MockEndpoint mockEndpoint, Func<HttpContext, (string Method, string Path, TBodyType Body), ILogger, Task<bool>> func)
        {
            mockEndpoint.CustomAssert(async (context, data, logger) =>
            {
                var requestBody = JsonConvert.DeserializeObject<TBodyType>(data.Body);
                return await func(context, (data.Method, data.Path, requestBody), logger);
            });

            return mockEndpoint;
        }
        
        public static MockEndpoint CustomAssert<TBodyType>(this MockEndpoint mockEndpoint, Func<HttpContext, (string Method, string Path, TBodyType Body), ILogger, bool> func)
        {
            return mockEndpoint.CustomAssert<TBodyType>((context, data, logger) =>
                Task.FromResult(func(context, data, logger)));
        }

        public static MockEndpoint OnCorrelationIdEqual(this MockEndpoint mockEndpoint, Guid correlationId)
        {
            mockEndpoint.Handlers.Add((context, _) =>
            {
                if (!context.Request.Headers.TryGetValue("CorrelationId", out var requestedCorrelationId))
                {
                    context.Request.Headers.TryGetValue("X-DB-CorrelId", out requestedCorrelationId);
                }

                var result = correlationId.ToString() == requestedCorrelationId;
                return Task.FromResult(result);
            });
            return mockEndpoint;
        }

        public static MockEndpoint ReturnsJson(this MockEndpoint mockEndpoint, HttpStatusCode httpStatusCode, object response)
        {
            mockEndpoint.Response = async context =>
            {
                context.Response.StatusCode = (int) httpStatusCode;
                context.Response.ContentType = "application/json";

                if (httpStatusCode == HttpStatusCode.NoContent)
                    return;
                
                await context.Response.WriteAsync(JsonConvert.SerializeObject(response));
            };
            return mockEndpoint;
        }

        public static MockEndpoint Returns(this MockEndpoint mockEndpoint, string response, HttpStatusCode httpStatusCode = HttpStatusCode.OK)
        {
            mockEndpoint.Response = async context =>
            {
                context.Response.StatusCode = (int) httpStatusCode;
                context.Response.ContentType = "application/json";
                
                if (httpStatusCode == HttpStatusCode.NoContent)
                    return;
                
                await context.Response.WriteAsync(response);
            };
            return mockEndpoint;
        }

        public static MockEndpoint Returns(this MockEndpoint mockEndpoint, params (HttpStatusCode, string)[] responses)
        {
            var index = 0;

            mockEndpoint.Response = async context =>
            {
                var responseToReturn = responses[index];
                context.Response.StatusCode = (int) responseToReturn.Item1;
                context.Response.ContentType = "application/json";
                
                if (responseToReturn.Item1 == HttpStatusCode.NoContent)
                    return;
                
                await context.Response.WriteAsync(responseToReturn.Item2);
                    
                index++;
                if (index >= responses.Length)
                    index = responses.Length - 1;
            };

            return mockEndpoint;
        }
        
        public static MockEndpoint Returns(this MockEndpoint mockEndpoint, params (HttpStatusCode, object)[] responses)
        {
            return mockEndpoint.Returns(responses.Select(x => (x.Item1, JsonConvert.SerializeObject(x.Item2))).ToArray());
        }
    }
}