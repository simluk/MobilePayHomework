using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Serilog;

namespace MobilePay.Shared.HttpServerMock
{
    public class MockEndpoint
    {
        public List<Func<HttpContext, ILogger, Task<bool>>> Handlers = new List<Func<HttpContext, ILogger, Task<bool>>>();
        public Func<HttpContext, Task> Response;
        public int MatchedCount { get; set; }
        public bool HasBeenMatched => MatchedCount > 0;

        public void VerifyMatched()
        {
            if (!HasBeenMatched)
                throw new HttpServerMockException(
                    $"Mock endpoint was not matched. Check logs for more information.");
        }

        public void VerifyMatched(int expectedTimes)
        {
            if (MatchedCount != expectedTimes)
                throw new HttpServerMockException(
                    $"Mock endpoint was matched {MatchedCount} and not {expectedTimes} times. Check logs for more information.");
        }
        
        public void VerifyNotMatched()
        {
            if (HasBeenMatched)
                throw new HttpServerMockException("Mock endpoint was matched. Check logs for more information.");
        }
    }
}