using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using MobilePay.Shared.HttpServerMock;
using Serilog;

namespace Sample.AcceptanceTests.Infrastructure
{
    public class HttpMockClient
    {
        private readonly HttpServerMock _httpServerMock;
        public readonly string Url;

        public HttpMockClient(HttpServerMock httpServerMock)
        {
            _httpServerMock = httpServerMock;
            Url = httpServerMock.Urls.FirstOrDefault();
        }

        public void SetupHttpMockClient(string response, HttpStatusCode returnHttpStatusCode, Guid correlationId, string url = "test/url/to/call")
        {
            _httpServerMock.RegisterMockEndpoint(
                new MockEndpoint()
                    .OnCorrelationIdEqual(correlationId)
                    .OnPathEqual(url)
                    .OnMethodEqual(HttpMethod.Post)
                    .Returns(response, returnHttpStatusCode));
        }

        public void SetupHttpMockClient(string response,
            HttpStatusCode returnHttpStatusCode,
            Guid correlationId,
            Func<HttpContext, ILogger, Task<bool>> customAssert,
            string url = "test/url/to/call")
        {
            _httpServerMock.RegisterMockEndpoint(
                new MockEndpoint()
                    .OnCorrelationIdEqual(correlationId)
                    .OnPathEqual(url)
                    .OnMethodEqual(HttpMethod.Post)
                    .CustomAssert(customAssert)
                    .Returns(response, returnHttpStatusCode));
        }
    }
}