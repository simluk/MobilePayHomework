using Microsoft.Extensions.DependencyInjection;
using Serilog;
using Xunit;

namespace Sample.AcceptanceTests
{
    [Collection(nameof(TestCollection))]
    public abstract class AcceptanceTestBase
    {
        protected AcceptanceTestBase(TestsFixtureData testFixtureContainer)
        {
            Logger = testFixtureContainer.ServiceProvider.GetRequiredService<ILogger>();
        }
        
        protected ILogger Logger { get; }
    }
}