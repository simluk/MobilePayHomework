using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using AutoFixture.Xunit2;
using Microsoft.Extensions.DependencyInjection;
using Sample.AcceptanceTests.Infrastructure;
using Xunit;

namespace Sample.AcceptanceTests.Tests
{
    [Collection(nameof(TestCollection))]
    public class Mocking_Should
    {
        private readonly HttpMockClient _httpMockClient;

        public Mocking_Should(TestsFixtureData data)
        {
            _httpMockClient = data.ServiceProvider.GetRequiredService<HttpMockClient>();
        }

        [Theory, AutoData]
        public async Task ReturnOkAndResponse_When_TestEndpointIsInvoked(string response, Guid correlationId)
        {
            _httpMockClient.SetupHttpMockClient(response, HttpStatusCode.OK, correlationId);

            await AssertTestUrlRespondsCorrectly(response, correlationId);
        }

        [Theory, AutoData]
        public async Task ReturnOkAndResponse_When_EndpointsAreBeingRegisteredConcurrently(string response, Guid correlationId)
        {
            var cts = new CancellationTokenSource();
            var ct = cts.Token;

            _ = Task.Factory.StartNew(() =>
            {
                while (!ct.IsCancellationRequested)
                {
                    _httpMockClient.SetupHttpMockClient(Guid.NewGuid().ToString(), HttpStatusCode.OK, Guid.NewGuid(), $"/{Guid.NewGuid()}");
                }
            }, ct);

            await Task.Delay(TimeSpan.FromMilliseconds(10), ct);

            _httpMockClient.SetupHttpMockClient(response, HttpStatusCode.OK, correlationId);

            await AssertTestUrlRespondsCorrectly(response, correlationId);

            cts.Cancel();
        }

        [Theory, AutoData]
        public async Task ReturnOkAndResponse_When_MultipleHandlersRegistered_ReadingTheStream(string response, Guid correlationId)
        {
            for (var i = 0; i < 10; i++)
            {
                _httpMockClient.SetupHttpMockClient(response, HttpStatusCode.OK, correlationId, async (context, _) =>
                {
                    using var sr = new StreamReader(context.Request.Body, leaveOpen: true);
                    await sr.ReadToEndAsync();

                    return false;
                });
            }

            _httpMockClient.SetupHttpMockClient(response, HttpStatusCode.OK, correlationId, (context, _) => Task.FromResult(true));

            await AssertTestUrlRespondsCorrectly(response, correlationId);
        }
        
        [Theory, AutoData]
        public async Task ReturnEmptyBody_When_StatusCodeIs204NoContent(string response, Guid correlationId)
        {
            _httpMockClient.SetupHttpMockClient(response, HttpStatusCode.NoContent, correlationId);

            await AssertTestUrlRespondsCorrectly(string.Empty, correlationId);
        }

        private async Task AssertTestUrlRespondsCorrectly(string response, Guid correlationId)
        {
            using var httpClient = new HttpClient();
            var httpRequestMessage = new HttpRequestMessage
            {
                Method = HttpMethod.Post,
                RequestUri = new Uri(_httpMockClient.Url + "/test/url/to/call"),
            };
            httpRequestMessage.Headers.Add("CorrelationId", correlationId.ToString());
            var result = await httpClient.SendAsync(httpRequestMessage);

            Assert.Equal(response, await result.Content.ReadAsStringAsync());
        }
    }
}