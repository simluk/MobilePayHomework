using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using AutoFixture.Xunit2;
using Microsoft.Extensions.DependencyInjection;
using MobilePay.Shared.HttpServerMock;
using Newtonsoft.Json;
using Xunit;

namespace Sample.AcceptanceTests.Tests
{
    [Collection(nameof(TestCollection))]
    public class FluentMockEndpointExtensions_Should
    {
        private readonly HttpServerMock _httpServerMock;

        public FluentMockEndpointExtensions_Should(TestsFixtureData data)
        {
            _httpServerMock = data.ServiceProvider.GetRequiredService<HttpServerMock>();
        }
        
        [Theory]
        [InlineAutoData("Foo/Bar/Test", "Foo/Bar/Test")]
        [InlineAutoData("Foo/Bar/Test", "Foo/Bar/Test/")]
        [InlineAutoData("Foo/Bar/Test", "/Foo/Bar/Test")]
        [InlineAutoData("Foo/Bar/Test", "/Foo/Bar/Test/")]
        [InlineAutoData("Foo/Bar/Test", "/Foo/Bar/Test?noise=true")]
        public async Task MatchGivenPathEquals(
            string searchPath,
            string actualPath,
            string response, 
            Guid correlationId)
        {
            _httpServerMock.RegisterMockEndpoint(
                new MockEndpoint()
                    .OnCorrelationIdEqual(correlationId)
                    .OnPathEqual(searchPath)
                    .Returns(response));
            
            await AssertApiCall(actualPath, response, correlationId);
        }
        
        [Theory]
        [InlineAutoData("Foo/Bar/Test", "Foo/Bar/Test")]
        [InlineAutoData("Bar/Test", "Foo/Bar/Test/")]
        [InlineAutoData("Foo/Bar/", "/Foo/Bar/Test")]
        [InlineAutoData("Foo", "/Foo/Bar/Test/")]
        [InlineAutoData("Test", "/Foo/Bar/Test?noise=true")]
        [InlineAutoData("Bar", "/Foo/Bar/Test?noise=true")]
        public async Task MatchGivenPathContains(
            string searchPath,
            string actualPath,
            string response, 
            Guid correlationId)
        {
            _httpServerMock.RegisterMockEndpoint(
                new MockEndpoint()
                    .OnCorrelationIdEqual(correlationId)
                    .OnPathContains(searchPath)
                    .Returns(response));
            
            await AssertApiCall(actualPath, response, correlationId);
        }
        
        [Theory, AutoData]
        public async Task MatchGivenOverlappingMockEndpointsForPathEquals(
            string response, 
            Guid correlationId)
        {
            _httpServerMock.RegisterMockEndpoint(
                new MockEndpoint()
                    .OnCorrelationIdEqual(correlationId)
                    .OnPathEqual("Foo/")
                    .Returns(response));
            
            _httpServerMock.RegisterMockEndpoint(
                new MockEndpoint()
                    .OnCorrelationIdEqual(correlationId)
                    .OnPathEqual("Foo/132/")
                    .Returns(response));
            
            await AssertApiCall("Foo/", response, correlationId);
            await AssertApiCall("Foo/132/", response, correlationId);
        }

        [Theory, AutoData]
        public async Task MatchGivenQuery(string response, Guid correlationId)
        {
            var query = "?Foo=Bar&Bas=Baz";
            _httpServerMock.RegisterMockEndpoint(
                new MockEndpoint()
                    .OnCorrelationIdEqual(correlationId)
                    .OnQueryEquals(query)
                    .Returns(response));
            
            await AssertApiCall(query, response, correlationId);
        }
        
        [Theory, AutoData]
        public async Task MatchGivenPathAndQuery(string response, Guid correlationId)
        {
            var queryAndPath = "Foo/Bar/Test?Foo=Bar&Bas=Baz";
            _httpServerMock.RegisterMockEndpoint(
                new MockEndpoint()
                    .OnCorrelationIdEqual(correlationId)
                    .OnPathQueryEquals(queryAndPath)
                    .Returns(response));
            
            await AssertApiCall(queryAndPath, response, correlationId);
        }

        [Theory, AutoData]
        public async Task MatchGivenBody(string path, string content, string response, Guid correlationId)
        {
            _httpServerMock.RegisterMockEndpoint(
                new MockEndpoint()
                    .OnCorrelationIdEqual(correlationId)
                    .OnBodyContains(content)
                    .Returns(response));
            
            await AssertApiCall(path, response, correlationId, content);
        }
        
        [Theory, AutoData]
        public async Task MatchGivenBodyWithMultipleResponses(
            string path, 
            string content, 
            string response,
            string response2,
            string response3,
            Guid correlationId)
        {
            _httpServerMock.RegisterMockEndpoint(
                new MockEndpoint()
                    .OnCorrelationIdEqual(correlationId)
                    .OnBodyContains(content)
                    .Returns(
                        (HttpStatusCode.OK, response),
                        (HttpStatusCode.OK, response2),
                        (HttpStatusCode.OK, response3)));
            
            await AssertApiCall(path, response, correlationId, content);
            await AssertApiCall(path, response2, correlationId, content);
            await AssertApiCall(path, response3, correlationId, content);
            await AssertApiCall(path, response3, correlationId, content);
        }
        
        [Theory, AutoData]
        public async Task CustomAssertWithMethodPathAndDeserializedBody(
            Guid correlationId,
            HttpMethod method, 
            string path, 
            string requestBody,
            string responseBody)
        {
            var callBuffer = new List<(string Method, string Path, string Body)>();
            
            _httpServerMock.RegisterMockEndpoint(
                new MockEndpoint()
                    .OnCorrelationIdEqual(correlationId)
                    .CustomAssert((context, data, logger) =>
                    {
                        callBuffer.Add((data.Method, data.Path, data.Body));
                        return Task.FromResult(true);
                    })
                    .Returns(responseBody));
            
            await SendRequest(method, path, correlationId, requestBody);
            
            var request = Assert.Single(callBuffer);
            Assert.Equal(method.ToString(), request.Method);
            Assert.Equal(path, request.Path);
            Assert.Equal(requestBody, request.Body);
        }
        
        [Theory, AutoData]
        public async Task MatchBodyAssert(string path, string response, Guid correlationId, TestRequest testRequest)
        {
            _httpServerMock.RegisterMockEndpoint(
                new MockEndpoint()
                    .OnCorrelationIdEqual(correlationId)
                    .CustomAssert<TestRequest>((context, data, logger) => 
                        data.Body.SomeGuid == testRequest.SomeGuid
                        && data.Body.SomeString == testRequest.SomeString
                        && data.Body.SomeDecimal == testRequest.SomeDecimal
                        && data.Body.SomeDateTimeOffset == testRequest.SomeDateTimeOffset)
                    .Returns(response));
            
            await AssertApiCall(path, response, correlationId, testRequest);
        }
        
        [Theory, AutoData]
        public async Task NotMatchBodyAssert(string path, string response, Guid correlationId, TestRequest testRequest)
        {
            _httpServerMock.RegisterMockEndpoint(
                new MockEndpoint()
                    .OnCorrelationIdEqual(correlationId)
                    .CustomAssert<TestRequest>((context, data, logger) => false)
                    .Returns(response));

            var result = await SendRequest(HttpMethod.Post, path, correlationId, JsonConvert.SerializeObject(testRequest));
            Assert.Equal($"Could not find handler. Remember to register a handler for request /{path}", await result.Content.ReadAsStringAsync());
        }
        
        [Theory, AutoData]
        public async Task NotThrowOnVerifyMatched_When_EndpointCalled(
            string path,
            string response, 
            Guid correlationId)
        {
            var mockEndpoint = _httpServerMock.RegisterMockEndpoint(
                new MockEndpoint()
                    .OnCorrelationIdEqual(correlationId)
                    .OnPathEqual(path)
                    .Returns(response));
            
            await AssertApiCall(path, response, correlationId);
            
            mockEndpoint.VerifyMatched();
        }
        
        [Theory, AutoData]
        public void ThrowOnVerifyMatched_When_EndpointNotCalled(
            string path,
            string response, 
            Guid correlationId)
        {
            var mockEndpoint = _httpServerMock.RegisterMockEndpoint(
                new MockEndpoint()
                    .OnCorrelationIdEqual(correlationId)
                    .OnPathEqual(path)
                    .Returns(response));
            
            var exception = Assert.Throws<HttpServerMockException>(() => mockEndpoint.VerifyMatched());
            Assert.Equal("Mock endpoint was not matched. Check logs for more information.", exception.Message);
        }
        
        [Theory, AutoData]
        public async Task ThrowOnVerifyNotMatched_When_EndpointCalled(
            string path,
            string response, 
            Guid correlationId)
        {
            var mockEndpoint = _httpServerMock.RegisterMockEndpoint(
                new MockEndpoint()
                    .OnCorrelationIdEqual(correlationId)
                    .OnPathEqual(path)
                    .Returns(response));
            
            await AssertApiCall(path, response, correlationId);
            
            var exception = Assert.Throws<HttpServerMockException>(() => mockEndpoint.VerifyNotMatched());
            Assert.Equal("Mock endpoint was matched. Check logs for more information.", exception.Message);
        }
        
        [Theory, AutoData]
        public void NotThrowOnVerifyNotMatched_When_EndpointNotCalled(
            string path,
            string response, 
            Guid correlationId)
        {
            var mockEndpoint = _httpServerMock.RegisterMockEndpoint(
                new MockEndpoint()
                    .OnCorrelationIdEqual(correlationId)
                    .OnPathEqual(path)
                    .Returns(response));

            mockEndpoint.VerifyNotMatched();
        }
        
        [Theory, AutoData]
        public void ThrowOnVerifyMatchedTimes_When_EndpointNotCalled(
            string path,
            string response, 
            Guid correlationId,
            int expectedTimes)
        {
            var mockEndpoint = _httpServerMock.RegisterMockEndpoint(
                new MockEndpoint()
                    .OnCorrelationIdEqual(correlationId)
                    .OnPathEqual(path)
                    .Returns(response));

            var exception = Assert.Throws<HttpServerMockException>(() => mockEndpoint.VerifyMatched(expectedTimes));
            Assert.Equal($"Mock endpoint was matched 0 and not {expectedTimes} times. Check logs for more information.", exception.Message);
        }
        
        [Theory, AutoData]
        public async Task NotThrowOnVerifyMatchedTimes_When_EndpointCalled(
            string path,
            string response, 
            Guid correlationId,
            int expectedTimes)
        {
            var mockEndpoint = _httpServerMock.RegisterMockEndpoint(
                new MockEndpoint()
                    .OnCorrelationIdEqual(correlationId)
                    .OnPathEqual(path)
                    .Returns(response));

            for (var i = 0; i < expectedTimes; i++)
                await AssertApiCall(path, response, correlationId);

            mockEndpoint.VerifyMatched(expectedTimes);
        }
        
        [Theory, AutoData]
        public async Task Count_MockEndpoint_Matches(
            string path,
            string response, 
            Guid correlationId,
            int expectedTimes)
        {
            var mockEndpoint = _httpServerMock.RegisterMockEndpoint(
                new MockEndpoint()
                    .OnCorrelationIdEqual(correlationId)
                    .OnPathEqual(path)
                    .Returns(response));

            for (var i = 0; i < expectedTimes; i++)
                await AssertApiCall(path, response, correlationId);

            Assert.Equal(expectedTimes, mockEndpoint.MatchedCount);
        }

        private async Task AssertApiCall(string pathAndQuery, string response, Guid correlationId, string content = "test")
        {
            var result = await SendRequest(HttpMethod.Post, pathAndQuery, correlationId, content);

            Assert.Equal(response, await result.Content.ReadAsStringAsync());
        }
        
        private Task AssertApiCall(string pathAndQuery, string response, Guid correlationId, object content)
        {
            return AssertApiCall(pathAndQuery, response, correlationId, JsonConvert.SerializeObject(content));
        }

        private async Task<HttpResponseMessage> SendRequest(
            HttpMethod method, 
            string pathAndQuery, 
            Guid correlationId,
            string content)
        {
            using var httpClient = new HttpClient();
            var httpRequestMessage = new HttpRequestMessage
            {
                Method = method,
                RequestUri = new Uri(_httpServerMock.Urls.First() + "/" + pathAndQuery),
                Content = new StringContent(content)
            };
            httpRequestMessage.Headers.Add("CorrelationId", correlationId.ToString());
            return await httpClient.SendAsync(httpRequestMessage);
        }
        
        public class TestRequest
        {
            public Guid SomeGuid { get; set; }
            public string SomeString { get; set; }
            public decimal SomeDecimal { get; set; }
            public DateTimeOffset SomeDateTimeOffset { get; set; }
        }
    }
}