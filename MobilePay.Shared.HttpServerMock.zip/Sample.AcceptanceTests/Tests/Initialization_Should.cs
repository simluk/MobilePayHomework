using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using AutoFixture.Xunit2;
using Microsoft.Extensions.Options;
using MobilePay.Shared.HttpServerMock;
using Sample.AcceptanceTests.Infrastructure;
using Serilog;
using Xunit;

namespace Sample.AcceptanceTests.Tests
{
    public class Initialization_Should : AcceptanceTestBase
    {
        public Initialization_Should(TestsFixtureData testFixtureContainer) : base(testFixtureContainer)
        {
        }
        
        [Theory, AutoData]
        public async Task Create_Server_On_Url_That_Was_Passed(string response, Guid correlationId)
        {
            var url = "http://localhost:32323";
            var httpServerMock = new HttpServerMock(Logger, Options.Create(new HttpServerMockConfiguration
            {
                BaseUrls = new string[]
                {
                    url
                }
            }));
            var httpMockClient = new HttpMockClient(httpServerMock);

            httpMockClient.SetupHttpMockClient(response, HttpStatusCode.OK, correlationId);

            await AssertApiCall(url, response, correlationId);
        }

        [Theory, AutoData]
        public async Task Create_Server_On_Multiple_Urls_That_Were_Passed(string response, Guid correlationId)
        {
            var firstUrl = "http://localhost:42424";
            var secondUrl = "http://localhost:52525";
            var configuration = new HttpServerMockConfiguration
            {
                BaseUrls = new string[]
                {
                    firstUrl,
                    secondUrl
                }
            };
            var httpServerMock = new HttpServerMock(Logger, Options.Create(configuration));
            var httpMockClient = new HttpMockClient(httpServerMock);

            httpMockClient.SetupHttpMockClient(response, HttpStatusCode.OK, correlationId);

            await AssertApiCall(firstUrl, response, correlationId);
            await AssertApiCall(secondUrl, response, correlationId);
        }

        private static async Task AssertApiCall(string url, string response, Guid correlationId)
        {
            using (var httpClient = new HttpClient())
            {
                var httpRequestMessage = new HttpRequestMessage
                {
                    Method = HttpMethod.Post,
                    RequestUri = new Uri($"{url}/test/url/to/call"),
                };
                httpRequestMessage.Headers.Add("CorrelationId", correlationId.ToString());
                var result = await httpClient.SendAsync(httpRequestMessage);

                Assert.Equal(response, await result.Content.ReadAsStringAsync());
            }
        }
    }
}