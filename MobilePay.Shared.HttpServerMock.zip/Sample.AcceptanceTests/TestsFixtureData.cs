using System;
using System.Threading.Tasks;
using DB.MobilePay.Shared.Logging.Extensions;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using MobilePay.Shared.HttpServerMock;
using Sample.AcceptanceTests.Infrastructure;
using Serilog;

namespace Sample.AcceptanceTests
{
    public class TestsFixtureData : IAsyncDisposable
    {
        public readonly ServiceProvider ServiceProvider;
        private readonly IServiceCollection _services = new ServiceCollection();

        public TestsFixtureData()
        {
            var configuration = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json")
                .Build();

            _services.AddSingleton((IConfiguration)configuration);

            _services.AddSerilogLogger();
            _services.AddHttpServerMock(configuration);
            _services.AddTransient<HttpMockClient>();
            
            ServiceProvider = _services.BuildServiceProvider();
        }

        public async ValueTask DisposeAsync()
        {
            if (ServiceProvider == null)
            {
                return;
            }
            
            await ServiceProvider.DisposeAsync();
        }
    }
}