using Xunit;

namespace Sample.AcceptanceTests
{
    [CollectionDefinition(nameof(TestCollection))]
    public class TestCollection : ICollectionFixture<TestsFixtureData> 
    {
    }
}