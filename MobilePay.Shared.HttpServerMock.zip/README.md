
# Description

  

This is a HTTP mock server to mock out another microservices.

  

## Changelog

| Version | Description |

| 6.2 | - Remove rarely used error logs to avoid extreme level of noise in bigger test suite setups.

| 6.1 | - Ensure we don't write to the response stream in case the status code is 204 No Content.

| 6.0 | - Bumped to .NET 5. Added extension method for registering HttpServerMock on DI Container, ensuring singleton instance. Added correlation id tracing.

| 5.3 | - CustomAssert with typed request body. Method to verify if MockEndpoint has been matched or not.

| 5.2 | - Add convenience overload of custom assert that include body as a string, path without starting '/' and http method.

| 5.1 | - Added ability to setup a chain of responses

| 5.0 | - No longer supports .netcore2.2

| | - Use IAsyncDisposable for HttpServerMock

| 4.0 | - Changed OnPathEqual to test for path equality rather than substring equality and to ignore trailing slashes '/'.

| | - Added OnPathContains for backwards compatibility.

| 3.0 | - Made handler collection thread-safe.

| | - Bumped to .netcore3.1

| 1.0 | Added the initial HTTP Mock Server

  


Look at the sample project for inspiration of how to use this Http Mock server

  
  

v.6.0.0:

You can setup HttpSeverMock on the DI Container, using two different extension methods:
```services.AddHttpServerMock(configuration)``` asserts that you have created a section in your Acceptance Tests' appsettings.json file.

Example appsettings.json:
```
"HttpServerMockConfiguration": {  
  "BaseUrls": ["http://localhost:5000"]  
}
```

You can also point directly to a property in your appsettings.json file, by providing a pointer to, where to find the urls to mock.

Example:
```services.AddHttpServerMock(configuration, "AppSettings.HttpServerMockUrls")```

appsettings.json:

````
"AppSettings": {  
  ...  
 "HttpServerMockUrls": ["http://localhost:5000"]  
}
```